<?php
// ══════════════════════════════════════════
//  PayBR Gateway — Configuração Central
// ══════════════════════════════════════════
define('DB_HOST',    'localhost');
define('DB_NAME',    'paybr_gateway');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_CHARSET', 'utf8mb4');

define('SITE_NAME',  'PayBR Gateway');
define('BASE_URL',   'http://localhost/gw');   // ← altere para seu domínio
define('TIMEZONE',   'America/Sao_Paulo');

date_default_timezone_set(TIMEZONE);
session_start();

// ── PDO singleton ──────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
             PDO::ATTR_EMULATE_PREPARES=>false]
        );
    } catch (PDOException $e) {
        die(json_encode(['error'=>'DB connection failed']));
    }
    return $pdo;
}

// ── Auth helpers ───────────────────────────
function authAdmin(): array {
    if (empty($_SESSION['admin_id'])) {
        header('Location: '.BASE_URL.'/admin/login.php'); exit;
    }
    $r = db()->prepare('SELECT * FROM admins WHERE id=? AND status="active"');
    $r->execute([$_SESSION['admin_id']]);
    $a = $r->fetch();
    if (!$a) { session_destroy(); header('Location: '.BASE_URL.'/admin/login.php'); exit; }
    return $a;
}

function authMerchant(): array {
    if (empty($_SESSION['merchant_id'])) {
        header('Location: '.BASE_URL.'/merchant/login.php'); exit;
    }
    $r = db()->prepare('SELECT * FROM merchants WHERE id=? AND status="active"');
    $r->execute([$_SESSION['merchant_id']]);
    $m = $r->fetch();
    if (!$m) { session_destroy(); header('Location: '.BASE_URL.'/merchant/login.php'); exit; }
    return $m;
}

function apiAuth(): array {
    $key = $_SERVER['HTTP_X_API_KEY']
        ?? (preg_match('/Bearer\s+(\S+)/i', $_SERVER['HTTP_AUTHORIZATION']??'', $m) ? $m[1] : null)
        ?? ($_GET['api_key'] ?? null);
    if (!$key) jsonOut(['error'=>'API Key obrigatória'], 401);
    $r = db()->prepare('SELECT * FROM merchants WHERE api_key=? AND status="active"');
    $r->execute([$key]);
    $merchant = $r->fetch();
    if (!$merchant) jsonOut(['error'=>'API Key inválida'], 401);
    return $merchant;
}

// ── Utilities ──────────────────────────────
function jsonOut(array $data, int $code=200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type,Authorization,X-API-Key');
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
    exit;
}

function uid(string $prefix=''): string {
    return $prefix.strtoupper(bin2hex(random_bytes(8)));
}

function money(float $v): string {
    return 'R$ '.number_format($v,2,',','.');
}

function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}

function csrfCheck(): void {
    if (($_POST['csrf']??'') !== ($_SESSION['csrf']??'x')) {
        die('Token inválido.');
    }
}

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function calcFee(float $amount, string $method, array $merchant): float {
    return match($method) {
        'pix'         => round($amount * ($merchant['taxa_pix']/100), 2),
        'credit_card' => round($amount * ($merchant['taxa_credito']/100), 2),
        'debit_card'  => round($amount * ($merchant['taxa_debito']/100), 2),
        'boleto'      => (float)$merchant['taxa_boleto'],
        default       => 0,
    };
}
