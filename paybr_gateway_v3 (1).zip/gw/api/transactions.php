<?php
require_once __DIR__.'/../includes/config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}

$merchant = apiAuth();
$db = db();
$id  = $_GET['id'] ?? null;
$act = $_GET['action'] ?? null;

// Estorno
if ($act === 'refund' && $id) {
    $t = $db->prepare('SELECT * FROM transactions WHERE txn_id=? AND merchant_id=?');
    $t->execute([$id,$merchant['id']]); $t=$t->fetch();
    if (!$t) jsonOut(['error'=>'Transação não encontrada'],404);
    if ($t['status']!=='approved') jsonOut(['error'=>'Somente transações aprovadas podem ser estornadas'],400);
    $db->prepare("UPDATE transactions SET status='refunded',refunded_at=NOW() WHERE txn_id=?")->execute([$id]);
    $db->prepare("UPDATE merchants SET balance=balance-? WHERE id=?")->execute([$t['net_amount'],$merchant['id']]);
    jsonOut(['success'=>true,'message'=>'Estorno realizado','txn_id'=>$id]);
}

// Consultar uma
if ($id && $_SERVER['REQUEST_METHOD']==='GET') {
    $t = $db->prepare('SELECT * FROM transactions WHERE txn_id=? AND merchant_id=?');
    $t->execute([$id,$merchant['id']]); $t=$t->fetch();
    if (!$t) jsonOut(['error'=>'Transação não encontrada'],404);
    jsonOut(['success'=>true,'data'=>fmt($t)]);
}

// Listar
$where=['merchant_id=?']; $params=[$merchant['id']];
if (!empty($_GET['status']))  {$where[]='status=?';   $params[]=$_GET['status'];}
if (!empty($_GET['method']))  {$where[]='method=?';   $params[]=$_GET['method'];}
if (!empty($_GET['start']))   {$where[]='DATE(created_at)>=?';$params[]=$_GET['start'];}
if (!empty($_GET['end']))     {$where[]='DATE(created_at)<=?';$params[]=$_GET['end'];}
$w=implode(' AND ',$where);

$per=min(100,(int)($_GET['per_page']??20));
$page=max(1,(int)($_GET['page']??1));
$off=($page-1)*$per;

$cnt=$db->prepare("SELECT COUNT(*) FROM transactions WHERE $w");
$cnt->execute($params); $total=$cnt->fetchColumn();

$stmt=$db->prepare("SELECT * FROM transactions WHERE $w ORDER BY created_at DESC LIMIT $per OFFSET $off");
$stmt->execute($params);

jsonOut(['success'=>true,'data'=>array_map('fmt',$stmt->fetchAll()),'meta'=>['total'=>(int)$total,'per_page'=>$per,'page'=>$page,'pages'=>(int)ceil($total/$per)]]);

function fmt(array $t): array {
    $ml=['pix'=>'PIX','credit_card'=>'Cartão Crédito','debit_card'=>'Cartão Débito','boleto'=>'Boleto'];
    $sl=['pending'=>'Aguardando','approved'=>'Aprovado','refused'=>'Recusado','refunded'=>'Estornado'];
    return [
        'id'             => $t['txn_id'],
        'order_id'       => $t['order_id'],
        'amount'         => (float)$t['amount'],
        'fee'            => (float)$t['fee'],
        'net_amount'     => (float)$t['net_amount'],
        'payment_method' => $t['method'],
        'payment_method_label' => $ml[$t['method']]??$t['method'],
        'status'         => $t['status'],
        'status_label'   => $sl[$t['status']]??$t['status'],
        'customer'       => ['name'=>$t['customer_name'],'email'=>$t['customer_email'],'document'=>$t['customer_doc']],
        'card'           => $t['card_last4'] ? ['last4'=>$t['card_last4'],'brand'=>$t['card_brand'],'installments'=>$t['installments']] : null,
        'pix'            => $t['pix_code'] ? ['code'=>$t['pix_code'],'expires_at'=>$t['pix_expires']] : null,
        'boleto'         => $t['boleto_code'] ? ['code'=>$t['boleto_code'],'url'=>$t['boleto_url'],'expires_at'=>$t['boleto_expires']] : null,
        'created_at'     => $t['created_at'],
        'approved_at'    => $t['approved_at'],
    ];
}
