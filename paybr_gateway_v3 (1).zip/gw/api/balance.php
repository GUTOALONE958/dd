<?php
require_once __DIR__.'/../includes/config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(200);exit;}

$m = apiAuth();
$db = db();

$s = $db->prepare("
    SELECT
        SUM(CASE WHEN status='approved' THEN net_amount ELSE 0 END) approved_net,
        SUM(CASE WHEN status='pending'  THEN amount ELSE 0 END) pending_vol,
        SUM(CASE WHEN status='approved' THEN fee ELSE 0 END) total_fees,
        COUNT(CASE WHEN status='approved' THEN 1 END) approved_count,
        COUNT(*) total_count
    FROM transactions WHERE merchant_id=?
");
$s->execute([$m['id']]); $s=$s->fetch();

$wd = $db->prepare("SELECT COALESCE(SUM(net_amount),0) FROM withdrawals WHERE merchant_id=? AND status IN ('completed','processing')");
$wd->execute([$m['id']]); $wd=$wd->fetchColumn();

jsonOut([
    'success' => true,
    'balance' => [
        'available'   => round(max(0,$m['balance']),2),
        'pending'     => round($s['pending_vol']??0,2),
        'total_in'    => round($m['total_in'],2),
        'total_fees'  => round($s['total_fees']??0,2),
    ],
    'transactions' => [
        'total'         => (int)$s['total_count'],
        'approved'      => (int)$s['approved_count'],
        'approval_rate' => $s['total_count']>0 ? round($s['approved_count']/$s['total_count']*100,1) : 0,
    ],
    'merchant' => [
        'id'     => $m['merchant_uid'],
        'name'   => $m['name'],
        'status' => $m['status'],
        'fees'   => ['pix'=>$m['taxa_pix'].'%','credit_card'=>$m['taxa_credito'].'%','debit_card'=>$m['taxa_debito'].'%','boleto'=>'R$ '.$m['taxa_boleto']],
    ]
]);
