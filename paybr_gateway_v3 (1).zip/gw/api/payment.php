<?php
require_once __DIR__.'/../includes/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST')    { jsonOut(['error'=>'Método não permitido'], 405); }

$merchant = apiAuth();
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) jsonOut(['error'=>'Body inválido — envie JSON'], 400);

// Validação básica
foreach (['amount','payment_method'] as $f) {
    if (empty($input[$f])) jsonOut(['error'=>"Campo obrigatório: {$f}"], 400);
}

$amount = round((float)$input['amount'], 2);
if ($amount <= 0) jsonOut(['error'=>'Valor deve ser maior que zero'], 400);

$method = $input['payment_method'];
if (!in_array($method, ['pix','credit_card','debit_card','boleto'])) {
    jsonOut(['error'=>'payment_method inválido. Use: pix, credit_card, debit_card, boleto'], 400);
}

// Taxas
$fee = calcFee($amount, $method, $merchant);
$net = round($amount - $fee, 2);

$txnId = uid('TXN');
$status = 'pending';
$extra  = [];

switch ($method) {
    case 'credit_card':
    case 'debit_card':
        if (empty($input['card']['number'])) jsonOut(['error'=>'Dados do cartão obrigatórios (card.number, card.holder, card.expiry, card.cvv)'], 400);
        $card = $input['card'];
        $num  = preg_replace('/\D/','', $card['number']);
        $last4 = substr($num,-4);
        $brand = detectBrand($num);
        $approved = simulateApproval($num);
        $status = $approved ? 'approved' : 'refused';
        $extra = ['card_last4'=>$last4,'card_brand'=>$brand,'installments'=>(int)($input['installments']??1)];
        break;

    case 'pix':
        $pixCode = generatePixCode($amount, $txnId);
        $extra = ['pix_code'=>$pixCode,'pix_expires'=>date('Y-m-d H:i:s',strtotime('+30 minutes'))];
        $status = 'pending';
        break;

    case 'boleto':
        $barcode = generateBarcode($txnId, $amount);
        $extra = ['boleto_code'=>$barcode,'boleto_url'=>BASE_URL.'/boleto.php?id='.$txnId,'boleto_expires'=>date('Y-m-d H:i:s',strtotime('+3 days'))];
        $status = 'pending';
        break;
}

$customer = $input['customer'] ?? [];
$db = db();

try {
    $db->prepare("
        INSERT INTO transactions
            (txn_id, merchant_id, order_id, amount, fee, net_amount, method, status,
             customer_name, customer_email, customer_doc, customer_phone, customer_ip,
             card_last4, card_brand, installments,
             pix_code, pix_expires, boleto_code, boleto_url, boleto_expires,
             approved_at, metadata)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ")->execute([
        $txnId, $merchant['id'], $input['order_id']??null,
        $amount, $fee, $net, $method, $status,
        $customer['name']??null, $customer['email']??null, $customer['document']??null, $customer['phone']??null,
        $_SERVER['REMOTE_ADDR']??null,
        $extra['card_last4']??null, $extra['card_brand']??null, $extra['installments']??1,
        $extra['pix_code']??null, $extra['pix_expires']??null,
        $extra['boleto_code']??null, $extra['boleto_url']??null, $extra['boleto_expires']??null,
        $status==='approved' ? date('Y-m-d H:i:s') : null,
        isset($input['metadata']) ? json_encode($input['metadata']) : null,
    ]);

    if ($status === 'approved') {
        $db->prepare("UPDATE merchants SET balance=balance+?, total_in=total_in+? WHERE id=?")
           ->execute([$net, $amount, $merchant['id']]);
    }

    $resp = [
        'success' => true,
        'transaction' => [
            'id'             => $txnId,
            'order_id'       => $input['order_id'] ?? null,
            'amount'         => $amount,
            'fee'            => $fee,
            'net_amount'     => $net,
            'payment_method' => $method,
            'status'         => $status,
            'created_at'     => date('c'),
        ]
    ];

    if ($method === 'credit_card' || $method === 'debit_card') {
        $resp['transaction']['card'] = ['last4'=>$extra['card_last4'],'brand'=>$extra['card_brand'],'installments'=>$extra['installments']];
    }
    if ($method === 'pix') {
        $resp['transaction']['pix'] = [
            'code'       => $extra['pix_code'],
            'qrcode_url' => 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data='.urlencode($extra['pix_code']),
            'expires_at' => $extra['pix_expires'],
        ];
    }
    if ($method === 'boleto') {
        $resp['transaction']['boleto'] = ['code'=>$extra['boleto_code'],'url'=>$extra['boleto_url'],'expires_at'=>$extra['boleto_expires']];
    }

    jsonOut($resp, 201);

} catch (Exception $e) {
    jsonOut(['error'=>'Erro interno: '.$e->getMessage()], 500);
}

function detectBrand(string $n): string {
    if (preg_match('/^4/',$n)) return 'visa';
    if (preg_match('/^5[1-5]/',$n)) return 'mastercard';
    if (preg_match('/^3[47]/',$n)) return 'amex';
    if (preg_match('/^(4011|6277|6362|650)/',$n)) return 'elo';
    if (preg_match('/^(38|60)/',$n)) return 'hipercard';
    return 'unknown';
}

function simulateApproval(string $num): bool {
    return !in_array(substr($num,-4), ['0000','1111','9999','4242']);
}

function generatePixCode(float $amount, string $txnId): string {
    $amt = str_pad(number_format($amount,2,'',''), 10,'0',STR_PAD_LEFT);
    return '00020126580014BR.GOV.BCB.PIX0136'.strtolower(str_replace('-','',bin2hex(random_bytes(8))))
          .'520400005303986540'.(strlen($amt)).$amt.'5802BR5915PayBR Gateway6008BRASILIA'
          .'62140510'.$txnId.'6304ABCD';
}

function generateBarcode(string $txnId, float $amount): string {
    $a = str_pad(str_replace('.','',number_format($amount,2)),10,'0',STR_PAD_LEFT);
    return '001'.rand(1,9).' '.rand(10000,99999).'.'.rand(100000,999999).' '
          .rand(10000,99999).'.'.rand(100000,999999).' '
          .rand(10000,99999).'.'.rand(100000,999999).' 1 '.str_pad(rand(7000,9000),4,'0',STR_PAD_LEFT).$a;
}
