<?php
require_once __DIR__.'/includes/config.php';
if (!empty($_SESSION['admin_id'])) {
    header('Location: '.BASE_URL.'/admin/index.php'); exit;
}
if (!empty($_SESSION['merchant_id'])) {
    header('Location: '.BASE_URL.'/merchant/index.php'); exit;
}
header('Location: '.BASE_URL.'/merchant/login.php'); exit;
