<?php
/**
 * PayBR Gateway — SDK PHP
 * Copie este arquivo para sua loja e use a classe abaixo.
 *
 * Exemplo rápido:
 *   $gw = new PayBR('pk_live_SUA_CHAVE', 'https://seusite.com/gw');
 *   $r  = $gw->pix(99.90, ['name'=>'João', 'email'=>'j@j.com'], 'PEDIDO-1');
 *   echo $r['transaction']['pix']['code'];
 */
class PayBR {

    public function __construct(
        private string $apiKey,
        private string $baseUrl = 'http://localhost/gw',
        private int $timeout = 30
    ) {}

    // ─── Métodos de cobrança ──────────────────

    public function pix(float $amount, array $customer=[], string $orderId='', array $metadata=[]): array {
        return $this->post('/api/payment', ['payment_method'=>'pix','amount'=>$amount,'order_id'=>$orderId,'customer'=>$customer,'metadata'=>$metadata]);
    }

    public function creditCard(float $amount, array $card, array $customer=[], int $installments=1, string $orderId=''): array {
        return $this->post('/api/payment', ['payment_method'=>'credit_card','amount'=>$amount,'card'=>$card,'installments'=>$installments,'customer'=>$customer,'order_id'=>$orderId]);
    }

    public function debitCard(float $amount, array $card, array $customer=[], string $orderId=''): array {
        return $this->post('/api/payment', ['payment_method'=>'debit_card','amount'=>$amount,'card'=>$card,'customer'=>$customer,'order_id'=>$orderId]);
    }

    public function boleto(float $amount, array $customer=[], string $orderId=''): array {
        return $this->post('/api/payment', ['payment_method'=>'boleto','amount'=>$amount,'customer'=>$customer,'order_id'=>$orderId]);
    }

    // ─── Consultas ────────────────────────────

    public function getTransaction(string $txnId): array {
        return $this->get("/api/transactions/{$txnId}");
    }

    public function listTransactions(array $filters=[]): array {
        return $this->get('/api/transactions?'.http_build_query($filters));
    }

    public function getBalance(): array {
        return $this->get('/api/balance');
    }

    public function refund(string $txnId): array {
        return $this->post("/api/transactions/{$txnId}/refund");
    }

    public function isApproved(string $txnId): bool {
        return ($this->getTransaction($txnId)['data']['status'] ?? '') === 'approved';
    }

    // ─── Webhook ──────────────────────────────

    public function verifyWebhook(string $payload, string $signature): bool {
        return hash_equals(hash_hmac('sha256', $payload, $this->apiKey), $signature);
    }

    // ─── HTTP ─────────────────────────────────

    private function post(string $path, array $body=[]): array {
        return $this->request('POST', $path, $body);
    }

    private function get(string $path): array {
        return $this->request('GET', $path);
    }

    private function request(string $method, string $path, array $body=[]): array {
        $ch = curl_init(rtrim($this->baseUrl,'/').$path);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $this->timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json','X-API-Key: '.$this->apiKey],
        ]);
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($err) return ['success'=>false,'error'=>$err,'http_code'=>0];
        $data = json_decode($res, true) ?? [];
        $data['http_code'] = $code;
        return $data;
    }
}

/* ── EXEMPLOS ──────────────────────────────────────────────────
require 'PayBR.php';
$gw = new PayBR('pk_live_SUA_CHAVE', 'https://brpay.elementfx.com/gw');

// PIX
$r = $gw->pix(99.90, ['name'=>'João Silva','email'=>'j@j.com','document'=>'000.000.000-00'], 'PEDIDO-001');
if ($r['success']) {
    echo $r['transaction']['pix']['code'];        // Código copia-e-cola
    echo $r['transaction']['pix']['qrcode_url'];  // QR code pronto
    echo $r['transaction']['id'];                 // ID para polling
}

// Cartão de Crédito
$r = $gw->creditCard(250.00,
    ['number'=>'4111111111111111','holder'=>'JOAO SILVA','expiry'=>'12/27','cvv'=>'123'],
    ['name'=>'João','email'=>'j@j.com'], 3, 'PEDIDO-002'
);
echo $r['transaction']['status']; // approved | refused

// Boleto
$r = $gw->boleto(150.00, ['name'=>'Maria','email'=>'m@m.com','document'=>'111.222.333-00']);
echo $r['transaction']['boleto']['code'];

// Consultar status (polling para PIX)
if ($gw->isApproved('TXN_XXXXXXXXXXXXXXXX')) {
    // confirmar pedido!
}

// Receber webhook
$payload = file_get_contents('php://input');
$sig     = $_SERVER['HTTP_X_PAYBR_SIGNATURE'] ?? '';
if ($gw->verifyWebhook($payload, $sig)) {
    $evt = json_decode($payload, true);
    if ($evt['event'] === 'transaction.approved') {
        // liberar produto...
    }
}
*/
