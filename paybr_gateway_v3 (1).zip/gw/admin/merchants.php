<?php
require_once __DIR__.'/../includes/config.php';
$admin = authAdmin();
$db = db();

$action = $_GET['action'] ?? '';
$error = ''; $success = '';

// New merchant
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'new') {
    csrfCheck();
    $name   = trim($_POST['name'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $pass   = $_POST['password'] ?? '';
    $taxa_pix = (float)($_POST['taxa_pix'] ?? 1.5);
    $taxa_cred = (float)($_POST['taxa_credito'] ?? 3.5);
    $taxa_deb  = (float)($_POST['taxa_debito'] ?? 2.5);
    $taxa_bol  = (float)($_POST['taxa_boleto'] ?? 3.50);

    if (!$name || !$email || !$pass) { $error = 'Preencha todos os campos.'; }
    else {
        $chk = $db->prepare('SELECT id FROM merchants WHERE email=?');
        $chk->execute([$email]);
        if ($chk->fetch()) { $error = 'E-mail já cadastrado.'; }
        else {
            $uid = uid('M'); $apiKey = uid('pk_live_'); $secret = uid('sk_live_');
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $db->prepare('INSERT INTO merchants (name,email,password,merchant_uid,api_key,secret_key,status,taxa_pix,taxa_credito,taxa_debito,taxa_boleto,balance,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,0,NOW())')
               ->execute([$name,$email,$hash,$uid,$apiKey,$secret,'active',$taxa_pix,$taxa_cred,$taxa_deb,$taxa_bol]);
            $success = "Lojista $name criado com sucesso!";
            $action = '';
        }
    }
}

// Toggle status
if (isset($_GET['toggle'])) {
    $mid = (int)$_GET['toggle'];
    $cur = $db->prepare('SELECT status FROM merchants WHERE id=?'); $cur->execute([$mid]); $cur=$cur->fetchColumn();
    $new = $cur === 'active' ? 'inactive' : 'active';
    $db->prepare('UPDATE merchants SET status=? WHERE id=?')->execute([$new, $mid]);
    header('Location: merchants.php'); exit;
}

$search = trim($_GET['q'] ?? '');
$where = $search ? 'WHERE name LIKE ? OR email LIKE ?' : '';
$params = $search ? ["%$search%","%$search%"] : [];
$stmt = $db->prepare("SELECT * FROM merchants $where ORDER BY created_at DESC");
$stmt->execute($params); $merchants = $stmt->fetchAll();
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lojistas — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--dark4:#1a2438;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.11);--text:#dde3f0;--muted:#7a8499;--faint:#2a3248;--blue:#3b82f6;--blue2:#60a5fa;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--sidebar:220px}
html,body{height:100%}body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--dark2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}.logo-wrap{display:flex;align-items:center;gap:10px}.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}.logo-text{font-size:18px;font-weight:800;letter-spacing:-.3px}.logo-text span{color:var(--blue2)}.logo-env{font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:1px}
.sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto}.nav-section{margin-bottom:6px}.nav-title{font-size:9px;letter-spacing:2px;color:var(--faint);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--muted);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}.nav-link:hover{background:rgba(255,255,255,.04);color:var(--text)}.nav-link.active{background:rgba(59,130,246,.12);color:var(--blue2);font-weight:600}.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:16px;border-top:1px solid var(--border)}.user-card{display:flex;align-items:center;gap:10px}.user-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--muted)}.user-logout{margin-left:auto;color:var(--muted);text-decoration:none;font-size:16px}.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}.topbar{height:58px;background:var(--dark2);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 28px;gap:16px;position:sticky;top:0;z-index:100}.topbar-title{font-size:16px;font-weight:700}.topbar-sub{font-size:12px;color:var(--muted);margin-left:auto;font-family:'JetBrains Mono',monospace}.topbar-btn{padding:7px 16px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid var(--border);background:var(--dark3);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .15s}.topbar-btn:hover{border-color:var(--border2);background:var(--dark4)}.topbar-btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}.topbar-btn.primary:hover{background:#2563eb}
.content{padding:24px 28px;flex:1}
.filters{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}.filters input{padding:8px 13px;border:1px solid var(--border);border-radius:8px;background:var(--dark3);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;outline:none;min-width:220px;flex:1}.filters input:focus{border-color:var(--blue)}.btn-filter{padding:8px 18px;background:var(--blue);color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif}
.card{background:var(--dark2);border:1px solid var(--border);border-radius:14px;overflow:hidden}.card-head{padding:18px 22px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}.card-title{font-size:14px;font-weight:700}
.tbl{width:100%;border-collapse:collapse;font-size:13px}.tbl th{text-align:left;padding:9px 14px;color:var(--muted);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}.tbl td{padding:13px 14px;border-bottom:1px solid var(--border);vertical-align:middle}.tbl tr:last-child td{border-bottom:none}.tbl tr:hover td{background:rgba(255,255,255,.015)}.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)}
.new-form{background:var(--dark2);border:1px solid var(--border);border-radius:14px;padding:24px;margin-bottom:20px}.new-form h3{font-size:15px;font-weight:700;margin-bottom:18px}.field{margin-bottom:14px}.field label{display:block;font-size:11px;font-weight:600;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}.field input{width:100%;padding:11px 14px;background:var(--dark3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:14px;outline:none;transition:all .2s}.field input:focus{border-color:var(--blue)}.row-4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px}.row-2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.btn-submit{padding:11px 24px;background:var(--blue);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif}.btn-cancel{padding:11px 20px;background:transparent;color:var(--muted);border:1px solid var(--border);border-radius:8px;font-size:14px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif;margin-left:10px;text-decoration:none}
.error-box{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:8px;padding:11px 14px;font-size:13px;color:#fca5a5;margin-bottom:14px}.success-box{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:8px;padding:11px 14px;font-size:13px;color:#6ee7b7;margin-bottom:14px}
.toggle-btn{padding:4px 12px;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;border:none;font-family:'JetBrains Mono',monospace;transition:all .15s}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--dark3);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:190}
@media(max-width:900px){.row-4{grid-template-columns:1fr 1fr}}
@media(max-width:640px){.hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}.sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}.main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}.row-4{grid-template-columns:1fr}.row-2{grid-template-columns:1fr}.tbl th:nth-child(3),.tbl td:nth-child(3),.tbl th:nth-child(4),.tbl td:nth-child(4){display:none}}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ADMIN PANEL</div></div></div></div>
  <nav class="sidebar-nav">
    <div class="nav-section"><div class="nav-title">Principal</div>
      <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
      <a href="merchants.php" class="nav-link active"><span class="ni">🏪</span> Lojistas</a>
      <a href="withdrawals.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    </div>
    <div class="nav-section"><div class="nav-title">Sistema</div>
      <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
      <a href="logs.php" class="nav-link"><span class="ni">📋</span> Logs</a>
    </div>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($admin['name'],0,1)) ?></div><div><div class="user-name"><?= e($admin['name']) ?></div><div class="user-role"><?= ucfirst($admin['role']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar">
    <div class="topbar-title">Lojistas</div>
    <div class="topbar-sub"><?= count($merchants) ?> lojistas</div>
    <a href="merchants.php?action=new" class="topbar-btn primary">+ Novo Lojista</a>
  </header>
  <div class="content">
    <?php if($error): ?><div class="error-box">&#9888; <?= e($error) ?></div><?php endif ?>
    <?php if($success): ?><div class="success-box">&#9989; <?= e($success) ?></div><?php endif ?>

    <?php if($action === 'new'): ?>
    <div class="new-form">
      <h3>Novo Lojista</h3>
      <form method="POST" action="merchants.php?action=new">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <div class="row-2">
          <div class="field"><label>Nome / Razão social</label><input type="text" name="name" required placeholder="Empresa XYZ"></div>
          <div class="field"><label>E-mail</label><input type="email" name="email" required placeholder="lojista@email.com"></div>
        </div>
        <div class="field"><label>Senha inicial</label><input type="password" name="password" required placeholder="Mín. 8 caracteres"></div>
        <div style="margin-bottom:10px;font-size:11px;font-weight:700;color:var(--muted);letter-spacing:.8px;text-transform:uppercase">Taxas</div>
        <div class="row-4">
          <div class="field"><label>PIX (%)</label><input type="number" name="taxa_pix" step="0.01" value="1.5"></div>
          <div class="field"><label>Crédito (%)</label><input type="number" name="taxa_credito" step="0.01" value="3.5"></div>
          <div class="field"><label>Débito (%)</label><input type="number" name="taxa_debito" step="0.01" value="2.5"></div>
          <div class="field"><label>Boleto (R$)</label><input type="number" name="taxa_boleto" step="0.01" value="3.50"></div>
        </div>
        <button type="submit" class="btn-submit">Criar Lojista</button>
        <a href="merchants.php" class="btn-cancel">Cancelar</a>
      </form>
    </div>
    <?php endif ?>

    <form method="GET" class="filters">
      <input type="text" name="q" placeholder="Buscar por nome ou e-mail..." value="<?= e($search) ?>">
      <button type="submit" class="btn-filter">Buscar</button>
    </form>

    <div class="card">
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>Nome</th><th>E-mail</th><th>ID</th><th>Saldo</th><th>Taxa PIX</th><th>Status</th><th>Ação</th></tr></thead>
          <tbody>
            <?php foreach($merchants as $mer): ?>
            <tr>
              <td style="font-weight:600"><?= e($mer['name']) ?></td>
              <td class="mono"><?= e($mer['email']) ?></td>
              <td class="mono"><?= e($mer['merchant_uid']) ?></td>
              <td style="font-family:'JetBrains Mono',monospace;color:var(--green)"><?= money($mer['balance']) ?></td>
              <td class="mono"><?= $mer['taxa_pix'] ?>%</td>
              <td><?php if($mer['status']==='active'): ?><span style="color:var(--green);font-size:12px;font-weight:600">● Ativo</span><?php else: ?><span style="color:var(--muted);font-size:12px;font-weight:600">○ Inativo</span><?php endif ?></td>
              <td>
                <a href="merchants.php?toggle=<?= $mer['id'] ?>" class="toggle-btn" style="background:<?= $mer['status']==='active' ? 'rgba(239,68,68,.15)' : 'rgba(16,185,129,.15)' ?>;color:<?= $mer['status']==='active' ? 'var(--red)' : 'var(--green)' ?>" onclick="return confirm('Alterar status?')">
                  <?= $mer['status']==='active' ? 'Desativar' : 'Ativar' ?>
                </a>
              </td>
            </tr>
            <?php endforeach ?>
            <?php if(!$merchants): ?><tr><td colspan="7" style="text-align:center;color:var(--muted);padding:32px">Nenhum lojista encontrado</td></tr><?php endif ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
