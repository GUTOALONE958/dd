<?php
require_once __DIR__.'/../includes/config.php';
$admin = authAdmin();
$db = db();

try { $db->exec('CREATE TABLE IF NOT EXISTS withdrawals (id INT AUTO_INCREMENT PRIMARY KEY, merchant_id INT NOT NULL, amount DECIMAL(12,2) NOT NULL, pix_key VARCHAR(255), status ENUM("pending","approved","rejected") DEFAULT "pending", note TEXT, created_at DATETIME NOT NULL, updated_at DATETIME, INDEX idx_merchant (merchant_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'); } catch(\Throwable $e) {}

$error = ''; $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $wid    = (int)$_POST['wid'];
    $action = $_POST['wd_action'] ?? '';
    $note   = trim($_POST['note'] ?? '');
    if (in_array($action, ['approved','rejected'])) {
        $wd = $db->prepare('SELECT * FROM withdrawals WHERE id=?'); $wd->execute([$wid]); $wd=$wd->fetch();
        if ($wd && $wd['status'] === 'pending') {
            $db->prepare('UPDATE withdrawals SET status=?,note=?,updated_at=NOW() WHERE id=?')->execute([$action,$note,$wid]);
            if ($action === 'rejected') {
                $db->prepare('UPDATE merchants SET balance=balance+? WHERE id=?')->execute([$wd['amount'],$wd['merchant_id']]);
            }
            $success = 'Saque ' . ($action==='approved'?'aprovado':'rejeitado') . '.';
        }
    }
}

$pending_count = $db->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();
$stmt = $db->query("SELECT w.*, m.name merchant_name FROM withdrawals w JOIN merchants m ON m.id=w.merchant_id ORDER BY w.created_at DESC LIMIT 50");
$wds = $stmt->fetchAll();
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Saques — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}:root{--dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--dark4:#1a2438;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.11);--text:#dde3f0;--muted:#7a8499;--faint:#2a3248;--blue:#3b82f6;--blue2:#60a5fa;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--sidebar:220px}html,body{height:100%}body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);display:flex;min-height:100vh}.sidebar{width:var(--sidebar);min-height:100vh;background:var(--dark2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}.logo-wrap{display:flex;align-items:center;gap:10px}.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}.logo-text{font-size:18px;font-weight:800;letter-spacing:-.3px}.logo-text span{color:var(--blue2)}.logo-env{font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px}.sidebar-nav{flex:1;padding:16px 12px}.nav-title{font-size:9px;letter-spacing:2px;color:var(--faint);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--muted);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}.nav-link:hover{background:rgba(255,255,255,.04);color:var(--text)}.nav-link.active{background:rgba(59,130,246,.12);color:var(--blue2);font-weight:600}.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}.nav-badge{margin-left:auto;background:var(--red);color:#fff;font-size:10px;font-weight:700;padding:1px 7px;border-radius:10px;font-family:'JetBrains Mono',monospace}.sidebar-user{padding:16px;border-top:1px solid var(--border)}.user-card{display:flex;align-items:center;gap:10px}.user-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--muted)}.user-logout{margin-left:auto;color:var(--muted);text-decoration:none;font-size:16px}.user-logout:hover{color:var(--red)}.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}.topbar{height:58px;background:var(--dark2);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 28px;gap:16px;position:sticky;top:0;z-index:100}.topbar-title{font-size:16px;font-weight:700}.content{padding:24px 28px;flex:1}.card{background:var(--dark2);border:1px solid var(--border);border-radius:14px;overflow:hidden}.tbl{width:100%;border-collapse:collapse;font-size:13px}.tbl th{text-align:left;padding:9px 14px;color:var(--muted);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}.tbl td{padding:13px 14px;border-bottom:1px solid var(--border);vertical-align:middle}.tbl tr:last-child td{border-bottom:none}.tbl tr:hover td{background:rgba(255,255,255,.015)}.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)}.success-box{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:8px;padding:11px 14px;font-size:13px;color:#6ee7b7;margin-bottom:14px}.page-head{margin-bottom:20px}.page-head h2{font-size:22px;font-weight:800}
.action-form{display:flex;gap:6px;align-items:center}.action-form select{padding:4px 8px;background:var(--dark3);border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:12px;font-family:'Plus Jakarta Sans',sans-serif;outline:none}.action-form button{padding:4px 12px;background:var(--blue);color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:600;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--dark3);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:190}
@media(max-width:640px){.hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}.sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}.main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}.tbl th:nth-child(3),.tbl td:nth-child(3){display:none}}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ADMIN PANEL</div></div></div></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="merchants.php" class="nav-link"><span class="ni">🏪</span> Lojistas</a>
    <a href="withdrawals.php" class="nav-link active"><span class="ni">↑</span> Saques<?php if($pending_count>0): ?><span class="nav-badge"><?=$pending_count?></span><?php endif ?></a>
    <div class="nav-title">Sistema</div>
    <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
    <a href="logs.php" class="nav-link"><span class="ni">📋</span> Logs</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($admin['name'],0,1)) ?></div><div><div class="user-name"><?= e($admin['name']) ?></div><div class="user-role"><?= ucfirst($admin['role']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Saques</div></header>
  <div class="content">
    <div class="page-head"><h2>Solicitações de Saque</h2></div>
    <?php if($success): ?><div class="success-box">&#9989; <?= e($success) ?></div><?php endif ?>
    <div class="card"><div style="overflow-x:auto">
      <table class="tbl">
        <thead><tr><th>Lojista</th><th>Valor</th><th>Chave PIX</th><th>Status</th><th>Data</th><th>Ação</th></tr></thead>
        <tbody>
          <?php foreach($wds as $w):
            $sc=['pending'=>['Pendente','#f59e0b'],'approved'=>['Aprovado','#10b981'],'rejected'=>['Rejeitado','#ef4444']];
            $s=$sc[$w['status']]??[$w['status'],'#9ca3af'];
          ?>
          <tr>
            <td style="font-weight:600"><?= e($w['merchant_name']) ?></td>
            <td style="font-family:'JetBrains Mono',monospace;font-weight:700;color:var(--yellow)"><?= money($w['amount']) ?></td>
            <td class="mono"><?= e(substr($w['pix_key'],0,30)) ?>...</td>
            <td><span style="color:<?=$s[1]?>;font-size:12px;font-weight:600"><?=$s[0]?></span></td>
            <td class="mono"><?= date('d/m/y H:i', strtotime($w['created_at'])) ?></td>
            <td>
              <?php if($w['status']==='pending'): ?>
              <form method="POST" class="action-form">
                <input type="hidden" name="csrf" value="<?= csrf() ?>">
                <input type="hidden" name="wid" value="<?= $w['id'] ?>">
                <select name="wd_action"><option value="approved">Aprovar</option><option value="rejected">Rejeitar</option></select>
                <button type="submit" onclick="return confirm('Confirmar?')">OK</button>
              </form>
              <?php else: ?>
              <span class="mono" style="color:var(--faint)"><?= e($w['note']??'—') ?></span>
              <?php endif ?>
            </td>
          </tr>
          <?php endforeach ?>
          <?php if(!$wds): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:28px">Nenhum saque</td></tr><?php endif ?>
        </tbody>
      </table>
    </div></div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
