<?php
require_once __DIR__.'/../includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM admins WHERE email=? AND status="active"');
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($pass, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        db()->prepare('UPDATE admins SET last_login=NOW() WHERE id=?')->execute([$admin['id']]);
        db()->prepare('INSERT INTO login_logs (user_type,user_id,ip,user_agent,success) VALUES ("admin",?,?,?,1)')
            ->execute([$admin['id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']??'']);
        header('Location: '.BASE_URL.'/admin/index.php'); exit;
    } else {
        $error = 'E-mail ou senha incorretos.';
        db()->prepare('INSERT INTO login_logs (user_type,user_id,ip,user_agent,success) VALUES ("admin",0,?,?,0)')
            ->execute([$_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']??'']);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — <?= SITE_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.12);--text:#dde3f0;--muted:#7a8499;--faint:#3a4259;--blue:#3b82f6;--blue2:#60a5fa;--green:#10b981;--red:#ef4444}
html{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center;position:relative;overflow-x:hidden}
.bg-grid{position:fixed;inset:0;background-image:linear-gradient(rgba(59,130,246,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(59,130,246,.04) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
.bg-glow{position:fixed;width:600px;height:600px;border-radius:50%;background:radial-gradient(circle,rgba(59,130,246,.12) 0%,transparent 70%);top:-200px;right:-200px;pointer-events:none;animation:pulse 6s ease-in-out infinite}
.bg-glow2{position:fixed;width:400px;height:400px;border-radius:50%;background:radial-gradient(circle,rgba(16,185,129,.08) 0%,transparent 70%);bottom:-100px;left:-100px;pointer-events:none;animation:pulse 8s ease-in-out infinite reverse}
@keyframes pulse{0%,100%{transform:scale(1);opacity:.6}50%{transform:scale(1.1);opacity:1}}
.login-wrap{width:100%;max-width:440px;padding:20px;position:relative;z-index:10}
.login-card{background:var(--dark2);border:1px solid var(--border);border-radius:20px;padding:44px 40px;box-shadow:0 32px 80px rgba(0,0,0,.5);animation:fadeUp .5s ease both}
@keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:36px;justify-content:center}
.brand-icon{width:46px;height:46px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;box-shadow:0 8px 20px rgba(59,130,246,.35);flex-shrink:0}
.brand-name{font-size:22px;font-weight:800;letter-spacing:-.5px}
.brand-name span{color:var(--blue2)}
.brand-badge{font-size:10px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:2px}
h1{font-size:24px;font-weight:700;letter-spacing:-.3px;margin-bottom:6px}
.subtitle{font-size:14px;color:var(--muted);margin-bottom:32px}
.field{margin-bottom:18px}
.field label{display:block;font-size:12px;font-weight:600;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;margin-bottom:8px}
.field input{width:100%;padding:13px 16px;background:var(--dark3);border:1.5px solid var(--border);border-radius:10px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;outline:none;transition:all .2s;-webkit-appearance:none}
.field input:focus{border-color:var(--blue);background:#0e1929;box-shadow:0 0 0 3px rgba(59,130,246,.15)}
.field input::placeholder{color:var(--faint)}
.error-box{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:12px 16px;font-size:13px;color:#fca5a5;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.btn-login{width:100%;padding:14px;margin-top:6px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);color:#fff;border:none;border-radius:10px;font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:700;cursor:pointer;transition:all .2s;box-shadow:0 6px 20px rgba(59,130,246,.35);-webkit-appearance:none}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(59,130,246,.45)}
.btn-login:active{transform:translateY(0)}
.login-footer{text-align:center;margin-top:28px;font-size:13px;color:var(--muted)}
.login-footer a{color:var(--blue2);text-decoration:none;font-weight:500}
.divider{display:flex;align-items:center;gap:12px;margin:24px 0;color:var(--faint);font-size:12px}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:var(--border)}
@media(max-width:480px){
  .login-wrap{padding:12px}
  .login-card{padding:28px 20px;border-radius:16px}
  h1{font-size:20px}
  .subtitle{font-size:13px}
}
</style>
</head>
<body>
<div class="bg-grid"></div>
<div class="bg-glow"></div>
<div class="bg-glow2"></div>

<div class="login-wrap">
  <div class="login-card">
    <div class="brand">
      <div class="brand-icon">&#9889;</div>
      <div>
        <div class="brand-name">Pay<span>BR</span></div>
        <div class="brand-badge">PAINEL ADMINISTRATIVO</div>
      </div>
    </div>

    <h1>Bem-vindo de volta</h1>
    <p class="subtitle">Entre com suas credenciais de administrador</p>

    <?php if ($error): ?>
    <div class="error-box">&#9888; <?= e($error) ?></div>
    <?php endif ?>

    <form method="POST">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <div class="field">
        <label>E-mail</label>
        <input type="email" name="email" placeholder="admin@paybr.com" value="<?= e($_POST['email']??'') ?>" required autofocus autocomplete="email">
      </div>
      <div class="field">
        <label>Senha</label>
        <input type="password" name="password" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn-login">Entrar no Painel &rarr;</button>
    </form>

    <div class="divider">acesso de lojistas</div>
    <div style="text-align:center">
      <a href="<?= BASE_URL ?>/merchant/login.php" style="color:var(--blue2);font-size:13px;text-decoration:none;font-weight:500">
        &rarr; Acessar &aacute;rea do lojista
      </a>
    </div>
  </div>

  <div class="login-footer">
    <?= SITE_NAME ?> &copy; <?= date('Y') ?> &mdash; Todos os direitos reservados
  </div>
</div>
</body>
</html>
