<?php
require_once __DIR__.'/../includes/config.php';
$admin = authAdmin();
$db = db();

$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $success = 'Configurações salvas.';
}
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configurações — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}:root{--dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.11);--text:#dde3f0;--muted:#7a8499;--faint:#2a3248;--blue:#3b82f6;--blue2:#60a5fa;--green:#10b981;--red:#ef4444;--sidebar:220px}html,body{height:100%}body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);display:flex;min-height:100vh}.sidebar{width:var(--sidebar);min-height:100vh;background:var(--dark2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}.logo-wrap{display:flex;align-items:center;gap:10px}.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}.logo-text{font-size:18px;font-weight:800}.logo-text span{color:var(--blue2)}.logo-env{font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px}.sidebar-nav{flex:1;padding:16px 12px}.nav-title{font-size:9px;letter-spacing:2px;color:var(--faint);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--muted);font-size:13.5px;font-weight:500;text-decoration:none;margin-bottom:1px}.nav-link:hover{background:rgba(255,255,255,.04);color:var(--text)}.nav-link.active{background:rgba(59,130,246,.12);color:var(--blue2);font-weight:600}.ni{width:20px;text-align:center;font-size:15px}.sidebar-user{padding:16px;border-top:1px solid var(--border)}.user-card{display:flex;align-items:center;gap:10px}.user-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px}.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--muted)}.user-logout{margin-left:auto;color:var(--muted);text-decoration:none;font-size:16px}.user-logout:hover{color:var(--red)}.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}.topbar{height:58px;background:var(--dark2);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 28px;position:sticky;top:0;z-index:100}.topbar-title{font-size:16px;font-weight:700}.content{padding:24px 28px;flex:1}.page-head{margin-bottom:22px}.page-head h2{font-size:22px;font-weight:800}.card{background:var(--dark2);border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:16px;max-width:600px}.card-head{padding:16px 20px;border-bottom:1px solid var(--border)}.card-title{font-size:14px;font-weight:700}.card-body{padding:20px}.info-row{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);font-size:13px}.info-row:last-child{border-bottom:none}.info-val{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--blue2)}.success-box{background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);border-radius:8px;padding:11px 14px;font-size:13px;color:#6ee7b7;margin-bottom:14px;max-width:600px}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--dark3);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:190}
@media(max-width:640px){.hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}.sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}.main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}.card{max-width:100%}}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ADMIN PANEL</div></div></div></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="merchants.php" class="nav-link"><span class="ni">🏪</span> Lojistas</a>
    <a href="withdrawals.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Sistema</div>
    <a href="settings.php" class="nav-link active"><span class="ni">⚙</span> Configurações</a>
    <a href="logs.php" class="nav-link"><span class="ni">📋</span> Logs</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($admin['name'],0,1)) ?></div><div><div class="user-name"><?= e($admin['name']) ?></div><div class="user-role"><?= ucfirst($admin['role']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Configurações</div></header>
  <div class="content">
    <div class="page-head"><h2>Configurações do Sistema</h2></div>
    <?php if($success): ?><div class="success-box">&#9989; <?= e($success) ?></div><?php endif ?>
    <div class="card">
      <div class="card-head"><div class="card-title">Informações do sistema</div></div>
      <div class="card-body">
        <div class="info-row"><span>Nome do site</span><span class="info-val"><?= SITE_NAME ?></span></div>
        <div class="info-row"><span>URL base</span><span class="info-val"><?= BASE_URL ?></span></div>
        <div class="info-row"><span>Timezone</span><span class="info-val"><?= TIMEZONE ?></span></div>
        <div class="info-row"><span>PHP Version</span><span class="info-val"><?= PHP_VERSION ?></span></div>
        <div class="info-row"><span>Banco de dados</span><span class="info-val"><?= DB_NAME ?> @ <?= DB_HOST ?></span></div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div class="card-title">Administrador</div></div>
      <div class="card-body">
        <div class="info-row"><span>Nome</span><span class="info-val"><?= e($admin['name']) ?></span></div>
        <div class="info-row"><span>E-mail</span><span class="info-val"><?= e($admin['email']) ?></span></div>
        <div class="info-row"><span>Função</span><span class="info-val"><?= ucfirst($admin['role']) ?></span></div>
        <div class="info-row"><span>Último acesso</span><span class="info-val"><?= $admin['last_login'] ? date('d/m/Y H:i', strtotime($admin['last_login'])) : '—' ?></span></div>
      </div>
    </div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
