<?php
require_once __DIR__.'/../includes/config.php';
$admin = authAdmin();
$db = db();

// Filtros
$where = ['1=1']; $params = [];
if (!empty($_GET['status']))  { $where[] = 't.status=?';  $params[] = $_GET['status']; }
if (!empty($_GET['method']))  { $where[] = 't.method=?';  $params[] = $_GET['method']; }
if (!empty($_GET['q']))       { $where[] = '(t.txn_id LIKE ? OR t.customer_name LIKE ? OR t.customer_email LIKE ?)'; $q='%'.$_GET['q'].'%'; $params=array_merge($params,[$q,$q,$q]); }
if (!empty($_GET['date_from'])){ $where[] = 'DATE(t.created_at)>=?'; $params[] = $_GET['date_from']; }
if (!empty($_GET['date_to']))  { $where[] = 'DATE(t.created_at)<=?'; $params[] = $_GET['date_to']; }
$w = implode(' AND ', $where);

// Paginação
$per = 20; $page = max(1,(int)($_GET['page']??1)); $offset=($page-1)*$per;
$total = $db->prepare("SELECT COUNT(*) FROM transactions t JOIN merchants m ON m.id=t.merchant_id WHERE $w");
$total->execute($params); $total=$total->fetchColumn();
$pages = max(1, ceil($total/$per));

$stmt = $db->prepare("SELECT t.*,m.name merchant_name FROM transactions t JOIN merchants m ON m.id=t.merchant_id WHERE $w ORDER BY t.created_at DESC LIMIT $per OFFSET $offset");
$stmt->execute($params); $rows=$stmt->fetchAll();

function badge(string $s): string {
    $map=['approved'=>['Aprovado','#10b981','rgba(16,185,129,.12)'],'pending'=>['Pendente','#f59e0b','rgba(245,158,11,.12)'],'refused'=>['Recusado','#ef4444','rgba(239,68,68,.12)'],'refunded'=>['Estornado','#60a5fa','rgba(96,165,250,.12)'],'processing'=>['Processando','#a78bfa','rgba(167,139,250,.12)'],'cancelled'=>['Cancelado','#9ca3af','rgba(156,163,175,.12)']];
    $b=$map[$s]??[$s,'#9ca3af','rgba(156,163,175,.12)'];
    return "<span style='padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;font-family:JetBrains Mono,monospace;background:{$b[2]};color:{$b[1]}'>{$b[0]}</span>";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Transações — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
<?php include __DIR__.'/css_base.php'; // will use inline styles below ?>
*{margin:0;padding:0;box-sizing:border-box}
:root{--dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--dark4:#1a2438;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.11);--text:#dde3f0;--muted:#7a8499;--faint:#2a3248;--blue:#3b82f6;--blue2:#60a5fa;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--sidebar:220px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--dark2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;letter-spacing:-.3px}
.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:1px}
.sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto}
.nav-section{margin-bottom:6px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--faint);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--muted);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:rgba(255,255,255,.04);color:var(--text)}
.nav-link.active{background:rgba(59,130,246,.12);color:var(--blue2);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}
.user-role{font-size:11px;color:var(--muted)}
.user-logout{margin-left:auto;color:var(--muted);text-decoration:none;font-size:16px;transition:color .15s}
.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:58px;background:var(--dark2);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 28px;gap:16px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.topbar-sub{font-size:12px;color:var(--muted);margin-left:auto;font-family:'JetBrains Mono',monospace}
.content{padding:24px 28px;flex:1}
.filters{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px}
.fi{padding:8px 14px;background:var(--dark3);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;outline:none;transition:border .2s}
.fi:focus{border-color:var(--blue)}
.fi option{background:var(--dark2)}
select.fi{cursor:pointer}
.btn{padding:8px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:1px solid var(--border);background:var(--dark3);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .15s}
.btn:hover{border-color:var(--border2);background:var(--dark4)}
.btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}
.btn.primary:hover{background:#2563eb}
.btn.success{background:rgba(16,185,129,.15);border-color:rgba(16,185,129,.3);color:var(--green)}
.card{background:var(--dark2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 14px;color:var(--muted);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}
.tbl td{padding:13px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:rgba(255,255,255,.015)}
.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)}
.amount{font-family:'JetBrains Mono',monospace;font-weight:600}
.amount.pos{color:var(--green)}
.pag{display:flex;align-items:center;gap:6px;padding:16px 22px;border-top:1px solid var(--border)}
.pag-info{font-size:12px;color:var(--muted);margin-right:auto;font-family:'JetBrains Mono',monospace}
.pag a,.pag span{padding:5px 11px;border-radius:6px;font-size:12px;border:1px solid var(--border);background:var(--dark3);color:var(--muted);text-decoration:none;transition:all .15s}
.pag a:hover{border-color:var(--border2);color:var(--text)}
.pag a.cur{background:var(--blue);border-color:var(--blue);color:#fff}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:var(--dark2)}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
</style>
</head>
<body>
<aside class="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">⚡</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ADMIN PANEL</div></div></div></div>
  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-title">Principal</div>
      <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
      <a href="transactions.php" class="nav-link active"><span class="ni">⇄</span> Transações</a>
      <a href="merchants.php" class="nav-link"><span class="ni">🏪</span> Lojistas</a>
      <a href="withdrawals.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    </div>
    <div class="nav-section">
      <div class="nav-title">Sistema</div>
      <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
    </div>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($admin['name'],0,1)) ?></div><div><div class="user-name"><?= e($admin['name']) ?></div><div class="user-role"><?= ucfirst($admin['role']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>

<div class="main">
  <header class="topbar">
    <div class="topbar-title">Transações</div>
    <div class="topbar-sub"><?= number_format($total) ?> registros</div>
    <a href="?<?= http_build_query(array_merge($_GET,['export'=>'csv'])) ?>" class="btn success">↓ Exportar CSV</a>
  </header>
  <div class="content">

    <form method="GET" class="filters">
      <input class="fi" name="q" placeholder="🔍  Buscar ID, nome, email..." value="<?= e($_GET['q']??'') ?>" style="min-width:240px">
      <select class="fi" name="status">
        <option value="">Todos os status</option>
        <?php foreach(['approved'=>'Aprovado','pending'=>'Pendente','refused'=>'Recusado','refunded'=>'Estornado','cancelled'=>'Cancelado'] as $v=>$l): ?>
        <option value="<?=$v?>" <?= ($_GET['status']??'')===$v?'selected':'' ?>><?=$l?></option>
        <?php endforeach ?>
      </select>
      <select class="fi" name="method">
        <option value="">Todos os métodos</option>
        <option value="pix" <?= ($_GET['method']??'')==='pix'?'selected':'' ?>>PIX</option>
        <option value="credit_card" <?= ($_GET['method']??'')==='credit_card'?'selected':'' ?>>Cartão Crédito</option>
        <option value="debit_card" <?= ($_GET['method']??'')==='debit_card'?'selected':'' ?>>Cartão Débito</option>
        <option value="boleto" <?= ($_GET['method']??'')==='boleto'?'selected':'' ?>>Boleto</option>
      </select>
      <input type="date" class="fi" name="date_from" value="<?= e($_GET['date_from']??'') ?>">
      <input type="date" class="fi" name="date_to" value="<?= e($_GET['date_to']??'') ?>">
      <button type="submit" class="btn primary">Filtrar</button>
      <a href="transactions.php" class="btn">Limpar</a>
    </form>

    <div class="card">
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead>
            <tr>
              <th>TXN ID</th><th>Lojista</th><th>Cliente</th><th>Método</th>
              <th>Valor</th><th>Taxa</th><th>Líquido</th><th>Status</th><th>Data</th><th>Ação</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($rows as $t): ?>
            <tr>
              <td><span class="mono"><?= e($t['txn_id']) ?></span></td>
              <td style="font-size:13px;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($t['merchant_name']) ?></td>
              <td>
                <div style="font-size:13px;font-weight:500"><?= e($t['customer_name']??'—') ?></div>
                <div class="mono" style="margin-top:2px"><?= e($t['customer_email']??'') ?></div>
              </td>
              <td style="font-size:13px">
                <?php $icons=['pix'=>'🏦','credit_card'=>'💳','debit_card'=>'🏧','boleto'=>'📄']; ?>
                <?= $icons[$t['method']]??'💰' ?>
                <?= ['pix'=>'PIX','credit_card'=>'Crédito','debit_card'=>'Débito','boleto'=>'Boleto'][$t['method']]??$t['method'] ?>
              </td>
              <td><span class="amount pos"><?= money($t['amount']) ?></span></td>
              <td><span class="mono" style="color:var(--red)">-<?= money($t['fee']) ?></span></td>
              <td><span class="mono" style="color:var(--green)"><?= money($t['net_amount']) ?></span></td>
              <td><?= badge($t['status']) ?></td>
              <td class="mono"><?= date('d/m/y H:i', strtotime($t['created_at'])) ?></td>
              <td>
                <?php if($t['status']==='approved'): ?>
                <a href="?action=refund&id=<?= $t['id'] ?>&csrf=<?= csrf() ?>" class="btn" style="font-size:11px;padding:4px 10px;color:var(--red);border-color:rgba(239,68,68,.2)" onclick="return confirm('Confirmar estorno?')">Estornar</a>
                <?php endif ?>
              </td>
            </tr>
            <?php endforeach ?>
            <?php if(!$rows): ?>
            <tr><td colspan="10" style="text-align:center;color:var(--muted);padding:40px">Nenhuma transação encontrada</td></tr>
            <?php endif ?>
          </tbody>
        </table>
      </div>
      <div class="pag">
        <span class="pag-info"><?= $total ?> registros · página <?= $page ?>/<?= $pages ?></span>
        <?php for($i=max(1,$page-2);$i<=min($pages,$page+3);$i++): ?>
        <a href="?<?= http_build_query(array_merge($_GET,['page'=>$i])) ?>" class="<?= $i===$page?'cur':'' ?>"><?= $i ?></a>
        <?php endfor ?>
      </div>
    </div>
  </div>
</div>

<?php
// Handle refund action
if (!empty($_GET['action']) && $_GET['action']==='refund' && !empty($_GET['id'])) {
    if (($_GET['csrf']??'') !== csrf()) die('Token inválido');
    $db->prepare("UPDATE transactions SET status='refunded', refunded_at=NOW() WHERE id=? AND status='approved'")->execute([(int)$_GET['id']]);
    header('Location: transactions.php?msg=refunded'); exit;
}

// Handle CSV export
if (!empty($_GET['export']) && $_GET['export']==='csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="transacoes_'.date('Ymd').'.csv"');
    $stmt2 = $db->prepare("SELECT t.*,m.name merchant_name FROM transactions t JOIN merchants m ON m.id=t.merchant_id WHERE $w ORDER BY t.created_at DESC");
    $stmt2->execute($params);
    $out = fopen('php://output','w');
    fputcsv($out,['ID','Lojista','Cliente','Email','Método','Valor','Taxa','Líquido','Status','Data']);
    while($r=$stmt2->fetch()) fputcsv($out,[$r['txn_id'],$r['merchant_name'],$r['customer_name'],$r['customer_email'],$r['method'],$r['amount'],$r['fee'],$r['net_amount'],$r['status'],$r['created_at']]);
    fclose($out); exit;
}
?>
</body>
</html>
