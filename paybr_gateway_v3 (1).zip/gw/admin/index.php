<?php
require_once __DIR__.'/../includes/config.php';
$admin = authAdmin();

$db = db();

// ── Stats ──────────────────────────────────
$stats = $db->query("
    SELECT
        COUNT(*) total_txn,
        SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) approved_txn,
        SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) total_vol,
        SUM(CASE WHEN status='approved' THEN fee ELSE 0 END) total_fee,
        SUM(CASE WHEN DATE(created_at)=CURDATE() AND status='approved' THEN amount ELSE 0 END) today_vol,
        SUM(CASE WHEN DATE(created_at)=CURDATE() THEN 1 ELSE 0 END) today_txn
    FROM transactions
")->fetch();

$merchants_count = $db->query("SELECT COUNT(*) FROM merchants WHERE status='active'")->fetchColumn();
$pending_wd = $db->query("SELECT COUNT(*) FROM withdrawals WHERE status='pending'")->fetchColumn();

// ── Chart data (últimos 7 dias) ─────────────
$chart = $db->query("
    SELECT DATE(created_at) d,
           SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) v,
           COUNT(*) c
    FROM transactions
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY d ASC
")->fetchAll();

// ── Últimas transações ─────────────────────
$recent = $db->query("
    SELECT t.*, m.name merchant_name
    FROM transactions t
    JOIN merchants m ON m.id=t.merchant_id
    ORDER BY t.created_at DESC LIMIT 10
")->fetchAll();

// ── Método breakdown ───────────────────────
$methods = $db->query("
    SELECT method,
           COUNT(*) c,
           SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) vol
    FROM transactions
    GROUP BY method
")->fetchAll(PDO::FETCH_KEY_PAIR|PDO::FETCH_UNIQUE);
$methods = $db->query("
    SELECT method, COUNT(*) c, SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) vol
    FROM transactions GROUP BY method
")->fetchAll();

$approval_rate = $stats['total_txn'] > 0
    ? round($stats['approved_txn'] / $stats['total_txn'] * 100, 1)
    : 0;

function badge(string $s): string {
    $map = [
        'approved'   => ['Aprovado','#10b981','rgba(16,185,129,.12)'],
        'pending'    => ['Pendente','#f59e0b','rgba(245,158,11,.12)'],
        'refused'    => ['Recusado','#ef4444','rgba(239,68,68,.12)'],
        'refunded'   => ['Estornado','#60a5fa','rgba(96,165,250,.12)'],
        'processing' => ['Processando','#a78bfa','rgba(167,139,250,.12)'],
        'cancelled'  => ['Cancelado','#9ca3af','rgba(156,163,175,.12)'],
    ];
    $b = $map[$s] ?? [$s,'#9ca3af','rgba(156,163,175,.12)'];
    return "<span style='padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;font-family:JetBrains Mono,monospace;background:{$b[2]};color:{$b[1]}'>{$b[0]}</span>";
}
function methodIcon(string $m): string {
    return match($m){
        'pix'=>'🏦','credit_card'=>'💳','debit_card'=>'🏧','boleto'=>'📄',default=>'💰'
    };
}
function methodLabel(string $m): string {
    return match($m){
        'pix'=>'PIX','credit_card'=>'Crédito','debit_card'=>'Débito','boleto'=>'Boleto',default=>$m
    };
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard — <?= SITE_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --dark:#080c14;--dark2:#0e1422;--dark3:#141d2e;--dark4:#1a2438;
  --border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.11);
  --text:#dde3f0;--muted:#7a8499;--faint:#2a3248;
  --blue:#3b82f6;--blue2:#60a5fa;
  --green:#10b981;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;
  --sidebar:220px;
}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--dark);color:var(--text);display:flex;min-height:100vh}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar);min-height:100vh;background:var(--dark2);
  border-right:1px solid var(--border);display:flex;flex-direction:column;
  position:fixed;top:0;left:0;z-index:200
}
.sidebar-logo{padding:24px 20px 20px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#3b82f6,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;letter-spacing:-.3px}
.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--muted);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:1px}

.sidebar-nav{flex:1;padding:16px 12px;overflow-y:auto}
.nav-section{margin-bottom:6px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--faint);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{
  display:flex;align-items:center;gap:10px;padding:9px 12px;
  border-radius:8px;color:var(--muted);font-size:13.5px;font-weight:500;
  text-decoration:none;transition:all .15s;margin-bottom:1px;cursor:pointer;border:none;background:none;width:100%
}
.nav-link:hover{background:rgba(255,255,255,.04);color:var(--text)}
.nav-link.active{background:rgba(59,130,246,.12);color:var(--blue2);font-weight:600}
.nav-link.active .ni{color:var(--blue)}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.nav-badge{margin-left:auto;background:var(--red);color:#fff;font-size:10px;font-weight:700;padding:1px 7px;border-radius:10px;font-family:'JetBrains Mono',monospace}

.sidebar-user{padding:16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}
.user-role{font-size:11px;color:var(--muted)}
.user-logout{margin-left:auto;color:var(--muted);text-decoration:none;font-size:16px;transition:color .15s}
.user-logout:hover{color:var(--red)}

/* ── MAIN ── */
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column;min-height:100vh}

.topbar{
  height:58px;background:var(--dark2);border-bottom:1px solid var(--border);
  display:flex;align-items:center;padding:0 28px;gap:16px;position:sticky;top:0;z-index:100
}
.topbar-title{font-size:16px;font-weight:700}
.topbar-sub{font-size:12px;color:var(--muted);margin-left:auto;font-family:'JetBrains Mono',monospace}
.topbar-btn{padding:7px 16px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;border:1px solid var(--border);background:var(--dark3);color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .15s}
.topbar-btn:hover{border-color:var(--border2);background:var(--dark4)}
.topbar-btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}
.topbar-btn.primary:hover{background:#2563eb}

.content{padding:24px 28px;flex:1}

/* ── STATS ── */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
.stat{background:var(--dark2);border:1px solid var(--border);border-radius:14px;padding:20px 22px;position:relative;overflow:hidden;transition:border-color .2s}
.stat:hover{border-color:var(--border2)}
.stat-label{font-size:11px;color:var(--muted);letter-spacing:.8px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;margin-bottom:10px}
.stat-val{font-size:26px;font-weight:800;letter-spacing:-1px;line-height:1}
.stat-footer{font-size:12px;color:var(--muted);margin-top:8px;display:flex;align-items:center;gap:5px}
.stat-footer .up{color:var(--green)}
.stat-footer .dn{color:var(--red)}
.stat-accent{position:absolute;top:0;right:0;width:3px;height:100%}

/* ── GRID ── */
.grid-2{display:grid;grid-template-columns:1fr 340px;gap:16px;margin-bottom:16px}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:16px}

/* ── CARD ── */
.card{background:var(--dark2);border:1px solid var(--border);border-radius:14px;overflow:hidden}
.card-head{padding:18px 22px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:14px;font-weight:700}
.card-sub{font-size:11px;color:var(--muted);font-family:'JetBrains Mono',monospace;margin-top:2px}
.card-body{padding:18px 22px}
.card-link{font-size:12px;color:var(--blue2);text-decoration:none;font-weight:500}
.card-link:hover{text-decoration:underline}

/* ── TABLE ── */
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:9px 14px;color:var(--muted);font-size:10px;letter-spacing:1.2px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}
.tbl td{padding:13px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:rgba(255,255,255,.015)}
.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted)}
.amount{font-family:'JetBrains Mono',monospace;font-weight:600}
.amount.pos{color:var(--green)}

/* ── METHOD BAR ── */
.method-row{display:flex;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid var(--border)}
.method-row:last-child{border-bottom:none}
.method-ico{width:38px;height:38px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.method-info{flex:1;min-width:0}
.method-name{font-size:13px;font-weight:600}
.method-cnt{font-size:11px;color:var(--muted);font-family:'JetBrains Mono',monospace;margin-top:2px}
.method-bar-wrap{flex:1;max-width:100px;height:4px;background:var(--dark3);border-radius:2px;overflow:hidden}
.method-bar{height:100%;border-radius:2px;transition:width .6s ease}
.method-pct{font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:600;min-width:36px;text-align:right}

/* ── CHART ── */
.chart-wrap{position:relative;height:160px}

/* ── ANIMS ── */
@keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}
.stat{animation:fadeUp .4s ease both}
.stat:nth-child(1){animation-delay:.05s}
.stat:nth-child(2){animation-delay:.1s}
.stat:nth-child(3){animation-delay:.15s}
.stat:nth-child(4){animation-delay:.2s}
.card{animation:fadeUp .4s ease .15s both}

/* scrollbar */
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:var(--dark2)}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}

/* ── MOBILE RESPONSIVE ── */
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--dark3);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:190;backdrop-filter:blur(2px)}

@media(max-width:900px){
  :root{--sidebar:220px}
  .stats-row{grid-template-columns:1fr 1fr}
  .grid-2{grid-template-columns:1fr}
}
@media(max-width:640px){
  .hamburger{display:flex}
  .sidebar{transform:translateX(-100%);transition:transform .25s ease}
  .sidebar.open{transform:translateX(0)}
  .sidebar-overlay.open{display:block}
  .main{margin-left:0}
  .topbar{padding:0 14px 0 60px}
  .content{padding:16px 14px}
  .stats-row{grid-template-columns:1fr}
  .grid-2{grid-template-columns:1fr}
  .stat-val{font-size:20px}
  .tbl th:nth-child(3),.tbl td:nth-child(3),
  .tbl th:nth-child(4),.tbl td:nth-child(4),
  .tbl th:nth-child(6),.tbl td:nth-child(6){display:none}
}
</style>
</head>
<body>

<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- ══ SIDEBAR ══ -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-wrap">
      <div class="logo-icon">⚡</div>
      <div>
        <div class="logo-text">Pay<span>BR</span></div>
        <div class="logo-env">ADMIN PANEL</div>
      </div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-title">Principal</div>
      <a href="index.php" class="nav-link active"><span class="ni">◈</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
      <a href="merchants.php" class="nav-link"><span class="ni">🏪</span> Lojistas</a>
      <a href="withdrawals.php" class="nav-link">
        <span class="ni">↑</span> Saques
        <?php if ($pending_wd > 0): ?><span class="nav-badge"><?= $pending_wd ?></span><?php endif ?>
      </a>
    </div>
    <div class="nav-section">
      <div class="nav-title">Sistema</div>
      <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
      <a href="logs.php" class="nav-link"><span class="ni">📋</span> Logs</a>
    </div>
  </nav>

  <div class="sidebar-user">
    <div class="user-card">
      <div class="user-avatar"><?= strtoupper(substr($admin['name'],0,1)) ?></div>
      <div>
        <div class="user-name"><?= e($admin['name']) ?></div>
        <div class="user-role"><?= ucfirst($admin['role']) ?></div>
      </div>
      <a href="logout.php" class="user-logout" title="Sair">⎋</a>
    </div>
  </div>
</aside>

<!-- ══ MAIN ══ -->
<div class="main">
  <header class="topbar">
    <div>
      <div class="topbar-title">Dashboard</div>
    </div>
    <div class="topbar-sub"><?= date('d/m/Y H:i') ?></div>
    <a href="merchants.php?action=new" class="topbar-btn primary">+ Novo Lojista</a>
  </header>

  <div class="content">

    <!-- ── STATS ── -->
    <div class="stats-row">
      <div class="stat">
        <div class="stat-accent" style="background:var(--green)"></div>
        <div class="stat-label">Volume Aprovado</div>
        <div class="stat-val" style="color:var(--green)"><?= money($stats['total_vol']??0) ?></div>
        <div class="stat-footer">
          <span>Hoje:</span>
          <span class="up"><?= money($stats['today_vol']??0) ?></span>
        </div>
      </div>
      <div class="stat">
        <div class="stat-accent" style="background:var(--blue)"></div>
        <div class="stat-label">Total Transações</div>
        <div class="stat-val" style="color:var(--blue2)"><?= number_format($stats['total_txn']??0) ?></div>
        <div class="stat-footer">Hoje: <span class="up"><?= $stats['today_txn']??0 ?></span></div>
      </div>
      <div class="stat">
        <div class="stat-accent" style="background:var(--yellow)"></div>
        <div class="stat-label">Taxa de Aprovação</div>
        <div class="stat-val" style="color:var(--yellow)"><?= $approval_rate ?>%</div>
        <div class="stat-footer">Últimos 30 dias</div>
      </div>
      <div class="stat">
        <div class="stat-accent" style="background:var(--purple)"></div>
        <div class="stat-label">Receita (Taxas)</div>
        <div class="stat-val" style="color:var(--purple)"><?= money($stats['total_fee']??0) ?></div>
        <div class="stat-footer"><span class="ni" style="font-size:12px">🏪</span> <?= $merchants_count ?> lojistas ativos</div>
      </div>
    </div>

    <!-- ── CHART + METHODS ── -->
    <div class="grid-2">
      <div class="card">
        <div class="card-head">
          <div>
            <div class="card-title">Volume dos Últimos 7 Dias</div>
            <div class="card-sub">Transações aprovadas · R$</div>
          </div>
        </div>
        <div class="card-body">
          <div class="chart-wrap">
            <canvas id="chartVol"></canvas>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head">
          <div class="card-title">Por Método de Pagamento</div>
        </div>
        <div class="card-body">
          <?php
          $total_m = array_sum(array_column($methods,'c')) ?: 1;
          $mcolors = ['pix'=>'#10b981','credit_card'=>'#3b82f6','debit_card'=>'#60a5fa','boleto'=>'#f59e0b'];
          $mbg     = ['pix'=>'rgba(16,185,129,.1)','credit_card'=>'rgba(59,130,246,.1)','debit_card'=>'rgba(96,165,250,.1)','boleto'=>'rgba(245,158,11,.1)'];
          foreach($methods as $row):
            $pct = round($row['c']/$total_m*100);
            $c = $mcolors[$row['method']] ?? '#9ca3af';
            $bg = $mbg[$row['method']] ?? 'rgba(156,163,175,.1)';
          ?>
          <div class="method-row">
            <div class="method-ico" style="background:<?= $bg ?>"><?= methodIcon($row['method']) ?></div>
            <div class="method-info">
              <div class="method-name"><?= methodLabel($row['method']) ?></div>
              <div class="method-cnt"><?= $row['c'] ?> transações · <?= money($row['vol']) ?></div>
            </div>
            <div class="method-bar-wrap">
              <div class="method-bar" style="width:<?= $pct ?>%;background:<?= $c ?>"></div>
            </div>
            <div class="method-pct" style="color:<?= $c ?>"><?= $pct ?>%</div>
          </div>
          <?php endforeach ?>
          <?php if (!$methods): ?>
          <div style="text-align:center;color:var(--muted);padding:20px;font-size:13px">Sem transações ainda</div>
          <?php endif ?>
        </div>
      </div>
    </div>

    <!-- ── RECENT TRANSACTIONS ── -->
    <div class="card">
      <div class="card-head">
        <div>
          <div class="card-title">Últimas Transações</div>
          <div class="card-sub">Atualizado agora</div>
        </div>
        <a href="transactions.php" class="card-link">Ver todas →</a>
      </div>
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead>
            <tr>
              <th>ID</th>
              <th>Lojista</th>
              <th>Cliente</th>
              <th>Método</th>
              <th>Valor</th>
              <th>Taxa</th>
              <th>Status</th>
              <th>Data</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($recent as $t): ?>
            <tr>
              <td><span class="mono"><?= e($t['txn_id']) ?></span></td>
              <td style="font-size:13px"><?= e($t['merchant_name']) ?></td>
              <td style="font-size:13px"><?= e($t['customer_name']??'—') ?></td>
              <td><?= methodIcon($t['method']) ?> <?= methodLabel($t['method']) ?></td>
              <td><span class="amount pos"><?= money($t['amount']) ?></span></td>
              <td><span class="mono" style="color:var(--red)">-<?= money($t['fee']) ?></span></td>
              <td><?= badge($t['status']) ?></td>
              <td class="mono"><?= date('d/m/y H:i', strtotime($t['created_at'])) ?></td>
            </tr>
            <?php endforeach ?>
            <?php if(!$recent): ?>
            <tr><td colspan="8" style="text-align:center;color:var(--muted);padding:32px">Nenhuma transação encontrada</td></tr>
            <?php endif ?>
          </tbody>
        </table>
      </div>
    </div>

  </div><!-- /content -->
</div><!-- /main -->

<script>
function toggleSidebar(){
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('open');
}
// Chart.js
const chartData = <?= json_encode($chart) ?>;
const labels = chartData.map(r => {
    const d = new Date(r.d+'T00:00:00');
    return d.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'});
});
const values = chartData.map(r => parseFloat(r.v||0));

new Chart(document.getElementById('chartVol'), {
  type: 'bar',
  data: {
    labels,
    datasets: [{
      data: values,
      backgroundColor: 'rgba(59,130,246,.25)',
      borderColor: '#3b82f6',
      borderWidth: 2,
      borderRadius: 6,
      hoverBackgroundColor: 'rgba(59,130,246,.45)',
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: {
      backgroundColor: '#0e1422', borderColor: 'rgba(255,255,255,.1)', borderWidth: 1,
      titleColor: '#dde3f0', bodyColor: '#7a8499',
      callbacks: { label: ctx => ' R$ ' + ctx.raw.toFixed(2).replace('.',',') }
    }},
    scales: {
      x: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#7a8499', font: { family: 'JetBrains Mono', size: 11 } } },
      y: { grid: { color: 'rgba(255,255,255,.04)' }, ticks: { color: '#7a8499', font: { family: 'JetBrains Mono', size: 11 },
          callback: v => 'R$'+v.toFixed(0) } }
    }
  }
});
</script>
</body>
</html>
