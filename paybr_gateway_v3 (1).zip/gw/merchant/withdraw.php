<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();
$db = db();
$mid = $m['id'];

// Create withdrawals table if not exists
try {
    $db->exec('CREATE TABLE IF NOT EXISTS withdrawals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        merchant_id INT NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        pix_key VARCHAR(255),
        status ENUM("pending","approved","rejected") DEFAULT "pending",
        note TEXT,
        created_at DATETIME NOT NULL,
        updated_at DATETIME,
        INDEX idx_merchant (merchant_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
} catch(\Throwable $e){}

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $amount  = (float)($_POST['amount']  ?? 0);
    $pix_key = trim($_POST['pix_key'] ?? '');

    if ($amount < 10) {
        $error = 'Valor mínimo para saque é R$ 10,00.';
    } elseif ($amount > (float)$m['balance']) {
        $error = 'Saldo insuficiente. Seu saldo disponível é ' . money($m['balance']) . '.';
    } elseif (!$pix_key) {
        $error = 'Informe a chave PIX para recebimento.';
    } else {
        $db->prepare('INSERT INTO withdrawals (merchant_id, amount, pix_key, status, created_at) VALUES (?, ?, ?, "pending", NOW())')
           ->execute([$mid, $amount, $pix_key]);
        // Deduct balance
        $db->prepare('UPDATE merchants SET balance = balance - ? WHERE id=?')->execute([$amount, $mid]);
        $m['balance'] -= $amount;
        $success = 'Solicitação de saque de ' . money($amount) . ' enviada com sucesso! Será processada em até 1 dia útil.';
    }
}

// History
$history = $db->prepare('SELECT * FROM withdrawals WHERE merchant_id=? ORDER BY created_at DESC LIMIT 20');
$history->execute([$mid]); $history = $history->fetchAll();
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Saques — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--sidebar:230px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;color:var(--text)}.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px}
.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}
.sb-label{font-size:10px;letter-spacing:1px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase}
.sb-val{font-size:20px;font-weight:800;letter-spacing:-1px;margin:4px 0;font-family:'JetBrains Mono',monospace}
.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:6px;border-radius:7px;margin-top:8px}
.sidebar-nav{flex:1;padding:14px 10px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:#f1f5f9;color:var(--text)}.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--text3)}
.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px}
.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.content{padding:22px 26px;flex:1}
.page-head{margin-bottom:22px}.page-head h2{font-size:22px;font-weight:800;letter-spacing:-.3px}
.page-head p{font-size:13px;color:var(--text3);margin-top:3px}
.grid{display:grid;grid-template-columns:420px 1fr;gap:20px}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.card-head{padding:16px 20px;border-bottom:1px solid var(--border)}
.card-title{font-size:14px;font-weight:700}
.card-body{padding:20px}
.bal-box{background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;padding:18px 20px;color:#fff;margin-bottom:18px}
.bal-label{font-size:11px;opacity:.8;font-family:'JetBrains Mono',monospace;letter-spacing:1px;text-transform:uppercase}
.bal-val{font-size:28px;font-weight:800;font-family:'JetBrains Mono',monospace;letter-spacing:-1px;margin-top:4px}
.field{margin-bottom:16px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field input{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;color:var(--text);outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus{border-color:var(--blue2);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.btn{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-appearance:none;margin-top:4px}
.btn:hover{background:#1d4ed8;transform:translateY(-1px)}
.error-box{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;font-size:13px;color:#b91c1c;margin-bottom:14px}
.success-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:11px 14px;font-size:13px;color:#166534;margin-bottom:14px}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 14px;color:var(--text3);font-size:10px;letter-spacing:1px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}
.tbl td{padding:12px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}.tbl tr:hover td{background:#f8faff}
.mono{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--text3)}
.amount{font-family:'JetBrains Mono',monospace;font-weight:700;color:var(--text)}
.info-box{background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 14px;font-size:12px;color:#1e40af;line-height:1.5;margin-top:12px}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--card);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:190}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
@media(max-width:640px){
  .hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}
  .sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}
  .main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}
}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ÁREA DO LOJISTA</div></div></div></div>
  <div class="sidebar-balance"><div class="sb-label">Saldo disponível</div><div class="sb-val"><?= money($m['balance']) ?></div><a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="withdraw.php" class="nav-link active"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Integração</div>
    <a href="api.php" class="nav-link"><span class="ni">⌥</span> API & Chaves</a>
    <a href="checkout_demo.php" class="nav-link"><span class="ni">▣</span> Checkout Demo</a>
    <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    <div class="nav-title">Conta</div>
    <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
    <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div><div><div class="user-name"><?= e(substr($m['name'],0,16)) ?></div><div class="user-role"><?= e($m['merchant_uid']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Saques</div></header>
  <div class="content">
    <div class="page-head"><h2>Solicitar Saque</h2><p>Transfira seu saldo para sua conta via PIX</p></div>
    <div class="grid">
      <div class="card">
        <div class="card-head"><div class="card-title">Nova solicitação</div></div>
        <div class="card-body">
          <div class="bal-box"><div class="bal-label">Saldo disponível</div><div class="bal-val"><?= money($m['balance']) ?></div></div>
          <?php if($error): ?><div class="error-box">&#9888; <?= e($error) ?></div><?php endif ?>
          <?php if($success): ?><div class="success-box">&#9989; <?= $success ?></div><?php endif ?>
          <form method="POST">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <div class="field">
              <label>Valor (R$)</label>
              <input type="number" name="amount" step="0.01" min="10" max="<?= $m['balance'] ?>" placeholder="Ex: 500.00" required>
            </div>
            <div class="field">
              <label>Chave PIX</label>
              <input type="text" name="pix_key" placeholder="CPF, CNPJ, e-mail ou chave aleatória" required>
            </div>
            <button type="submit" class="btn">Solicitar saque →</button>
          </form>
          <div class="info-box">&#8505; Saques são processados em até 1 dia útil. Mínimo de R$ 10,00 por solicitação.</div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Histórico de saques</div></div>
        <div style="overflow-x:auto">
          <table class="tbl">
            <thead><tr><th>Valor</th><th>Chave PIX</th><th>Status</th><th>Data</th></tr></thead>
            <tbody>
              <?php foreach($history as $w): 
                $sc=['pending'=>['Pendente','#f59e0b','rgba(245,158,11,.1)'],'approved'=>['Aprovado','#10b981','rgba(16,185,129,.1)'],'rejected'=>['Rejeitado','#ef4444','rgba(239,68,68,.1)']];
                $s=$sc[$w['status']]??[$w['status'],'#9ca3af','rgba(156,163,175,.1)'];
              ?>
              <tr>
                <td><span class="amount">- <?= money($w['amount']) ?></span></td>
                <td><span class="mono"><?= e(substr($w['pix_key'],0,24)) ?>...</span></td>
                <td><span style="padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;background:<?=$s[2]?>;color:<?=$s[1]?>"><?=$s[0]?></span></td>
                <td class="mono"><?= date('d/m/y H:i', strtotime($w['created_at'])) ?></td>
              </tr>
              <?php endforeach ?>
              <?php if(!$history): ?><tr><td colspan="4" style="text-align:center;color:var(--text3);padding:28px">Nenhum saque solicitado</td></tr><?php endif ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
