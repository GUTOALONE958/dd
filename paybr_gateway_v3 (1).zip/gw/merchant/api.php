<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();

$success = '';
// Regenerate keys
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['regen'])) {
    csrfCheck();
    $newApi    = uid('pk_live_');
    $newSecret = uid('sk_live_');
    db()->prepare('UPDATE merchants SET api_key=?, secret_key=? WHERE id=?')->execute([$newApi, $newSecret, $m['id']]);
    $m['api_key']    = $newApi;
    $m['secret_key'] = $newSecret;
    $success = 'Chaves regeneradas com sucesso!';
}
$base = BASE_URL;
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>API & Chaves — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--sidebar:230px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;color:var(--text)}.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px}
.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}
.sb-label{font-size:10px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:1px}
.sb-val{font-size:20px;font-weight:800;font-family:'JetBrains Mono',monospace;margin:4px 0}
.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:6px;border-radius:7px;margin-top:8px}
.sidebar-nav{flex:1;padding:14px 10px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:#f1f5f9;color:var(--text)}.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--text3)}
.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px}.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.content{padding:22px 26px;flex:1}
.page-head{margin-bottom:22px}.page-head h2{font-size:22px;font-weight:800;letter-spacing:-.3px}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:16px}
.card-head{padding:16px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:14px;font-weight:700}
.card-body{padding:20px}
.key-row{margin-bottom:16px}
.key-label{font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.key-box{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px 14px;font-family:'JetBrains Mono',monospace;font-size:12px;word-break:break-all;display:flex;align-items:center;justify-content:space-between;gap:10px}
.key-val{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.btn-copy{padding:5px 12px;background:var(--blue);color:#fff;border:none;border-radius:6px;font-size:11px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif;font-weight:600;flex-shrink:0;transition:background .15s}
.btn-copy:hover{background:#1d4ed8}
.warn-box{background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px 14px;font-size:12px;color:#92400e;line-height:1.5;margin-bottom:16px}
.endpoint{background:#0f172a;border-radius:8px;padding:14px 16px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#e2e8f0;overflow-x:auto;margin-bottom:10px;line-height:1.6}
.endpoint .method{color:#60a5fa;font-weight:700}.endpoint .url{color:#a3e635}
.endpoint .comment{color:#6b7280}
.success-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:11px 14px;font-size:13px;color:#166534;margin-bottom:14px}
.btn-regen{padding:8px 16px;background:#ef4444;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--card);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:190}
@media(max-width:640px){
  .hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}
  .sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}
  .main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}
}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ÁREA DO LOJISTA</div></div></div></div>
  <div class="sidebar-balance"><div class="sb-label">Saldo disponível</div><div class="sb-val"><?= money($m['balance']) ?></div><a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="withdraw.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Integração</div>
    <a href="api.php" class="nav-link active"><span class="ni">⌥</span> API & Chaves</a>
    <a href="checkout_demo.php" class="nav-link"><span class="ni">▣</span> Checkout Demo</a>
    <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    <div class="nav-title">Conta</div>
    <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
    <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div><div><div class="user-name"><?= e(substr($m['name'],0,16)) ?></div><div class="user-role"><?= e($m['merchant_uid']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">API & Chaves</div></header>
  <div class="content">
    <div class="page-head"><h2>Suas Chaves de API</h2></div>
    <?php if($success): ?><div class="success-box">&#9989; <?= e($success) ?></div><?php endif ?>
    <div class="card">
      <div class="card-head">
        <div class="card-title">Credenciais de Acesso</div>
        <form method="POST" onsubmit="return confirm('Regenerar chaves? As chaves atuais serão inválidas.')">
          <input type="hidden" name="csrf" value="<?= csrf() ?>">
          <input type="hidden" name="regen" value="1">
          <button type="submit" class="btn-regen">&#8635; Regenerar chaves</button>
        </form>
      </div>
      <div class="card-body">
        <div class="warn-box">&#9888; Nunca exponha a chave secreta (<code>sk_live_</code>) no frontend ou em repositórios públicos.</div>
        <div class="key-row">
          <div class="key-label">Chave Pública (API Key)</div>
          <div class="key-box"><span class="key-val" style="color:var(--blue)"><?= e($m['api_key']) ?></span><button class="btn-copy" onclick="copy('<?= e($m['api_key']) ?>',this)">Copiar</button></div>
        </div>
        <div class="key-row">
          <div class="key-label">Chave Secreta</div>
          <div class="key-box"><span class="key-val" id="sk-val" style="color:var(--red)">sk_live_••••••••••••••••••••••••</span><button class="btn-copy" id="sk-btn" onclick="revealSk()">Revelar</button></div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div class="card-title">Documentação da API</div></div>
      <div class="card-body">
        <p style="font-size:13px;color:var(--text2);margin-bottom:16px">URL base: <code style="font-family:'JetBrains Mono',monospace;background:var(--bg);padding:2px 6px;border-radius:4px"><?= BASE_URL ?>/api/</code></p>
        <div class="endpoint"><span class="method">POST</span> <span class="url">/api/payment.php</span><br><span class="comment">// Criar um pagamento</span><br>Headers: X-API-Key: pk_live_...<br>Body: { "amount": 100.00, "method": "pix", "customer_name": "...", "customer_email": "..." }</div>
        <div class="endpoint"><span class="method">GET</span> <span class="url">/api/transactions.php</span><br><span class="comment">// Listar transações</span><br>Headers: X-API-Key: pk_live_...</div>
        <div class="endpoint"><span class="method">GET</span> <span class="url">/api/balance.php</span><br><span class="comment">// Consultar saldo</span><br>Headers: X-API-Key: pk_live_...</div>
      </div>
    </div>
  </div>
</div>
<script>
const sk='<?= e($m['secret_key']) ?>';
let revealed=false;
function revealSk(){if(!revealed){document.getElementById('sk-val').textContent=sk;document.getElementById('sk-btn').textContent='Copiar';revealed=true;}else{copy(sk,document.getElementById('sk-btn'));}}
function copy(t,btn){navigator.clipboard.writeText(t).then(()=>{const o=btn.textContent;btn.textContent='✓';btn.style.background='#10b981';setTimeout(()=>{btn.textContent=o;btn.style.background=''},2000)});}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}
</script>
</body></html>
