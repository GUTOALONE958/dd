<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simulate'])) {
    csrfCheck();
    $amount   = (float)($_POST['amount']  ?? 0);
    $method   = $_POST['method']   ?? 'pix';
    $cname    = trim($_POST['customer_name']  ?? '');
    $cemail   = trim($_POST['customer_email'] ?? '');
    $statuses = ['approved','approved','approved','pending','refused'];
    $status   = $statuses[array_rand($statuses)];
    $fee      = calcFee($amount, $method, $m);
    $net      = $amount - $fee;
    $txnId    = uid('TXN');
    if ($amount > 0 && $cname && $cemail) {
        try {
            db()->prepare('INSERT INTO transactions (txn_id,merchant_id,amount,fee,net_amount,method,status,customer_name,customer_email,created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())')
               ->execute([$txnId, $m['id'], $amount, $fee, $net, $method, $status, $cname, $cemail]);
            if ($status === 'approved') {
                db()->prepare('UPDATE merchants SET balance = balance + ? WHERE id=?')->execute([$net, $m['id']]);
            }
        } catch(\Throwable $e) { /* table may need different cols */ }
        $result = compact('txnId','amount','fee','net','method','status','cname','cemail');
    }
}
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Checkout Demo — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--sidebar:230px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;color:var(--text)}.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px}
.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}
.sb-label{font-size:10px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:1px}
.sb-val{font-size:20px;font-weight:800;font-family:'JetBrains Mono',monospace;margin:4px 0}
.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:6px;border-radius:7px;margin-top:8px}
.sidebar-nav{flex:1;padding:14px 10px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:#f1f5f9;color:var(--text)}.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--text3)}
.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px}.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.content{padding:22px 26px;flex:1}
.page-head{margin-bottom:22px}.page-head h2{font-size:22px;font-weight:800}
.grid{display:grid;grid-template-columns:480px 1fr;gap:20px}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.card-head{padding:16px 20px;border-bottom:1px solid var(--border)}.card-title{font-size:14px;font-weight:700}
.card-body{padding:20px}
.field{margin-bottom:14px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field input,.field select{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:8px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;color:var(--text);outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus,.field select:focus{border-color:var(--blue2);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.row-2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;margin-top:4px}
.btn:hover{background:#1d4ed8;transform:translateY(-1px)}
.result-box{border-radius:10px;padding:18px 20px;margin-top:16px}
.result-box.approved{background:#f0fdf4;border:1px solid #bbf7d0}
.result-box.pending{background:#fffbeb;border:1px solid #fde68a}
.result-box.refused{background:#fef2f2;border:1px solid #fecaca}
.result-title{font-size:16px;font-weight:800;margin-bottom:10px}
.result-row{display:flex;justify-content:space-between;font-size:13px;padding:4px 0;border-bottom:1px solid rgba(0,0,0,.05)}
.result-row:last-child{border-bottom:none}
.mono{font-family:'JetBrains Mono',monospace;font-size:12px}
.info-box{background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 14px;font-size:12px;color:#1e40af;line-height:1.5}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--card);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:190}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
@media(max-width:640px){
  .hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}
  .sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}
  .main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}
  .row-2{grid-template-columns:1fr}
}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ÁREA DO LOJISTA</div></div></div></div>
  <div class="sidebar-balance"><div class="sb-label">Saldo disponível</div><div class="sb-val"><?= money($m['balance']) ?></div><a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="withdraw.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Integração</div>
    <a href="api.php" class="nav-link"><span class="ni">⌥</span> API & Chaves</a>
    <a href="checkout_demo.php" class="nav-link active"><span class="ni">▣</span> Checkout Demo</a>
    <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    <div class="nav-title">Conta</div>
    <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
    <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div><div><div class="user-name"><?= e(substr($m['name'],0,16)) ?></div><div class="user-role"><?= e($m['merchant_uid']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Checkout Demo</div></header>
  <div class="content">
    <div class="page-head"><h2>Simular Pagamento</h2></div>
    <div class="grid">
      <div class="card">
        <div class="card-head"><div class="card-title">Novo pagamento de teste</div></div>
        <div class="card-body">
          <div class="info-box" style="margin-bottom:16px">&#127379; Este é um ambiente de teste. As transações são reais no banco de dados mas sem movimentação financeira real.</div>
          <form method="POST">
            <input type="hidden" name="csrf" value="<?= csrf() ?>">
            <input type="hidden" name="simulate" value="1">
            <div class="row-2">
              <div class="field"><label>Valor (R$)</label><input type="number" name="amount" step="0.01" min="1" placeholder="100.00" required></div>
              <div class="field"><label>Método</label>
                <select name="method">
                  <option value="pix">🏦 PIX (taxa: <?= $m['taxa_pix'] ?>%)</option>
                  <option value="credit_card">💳 Crédito (<?= $m['taxa_credito'] ?>%)</option>
                  <option value="debit_card">🏧 Débito (<?= $m['taxa_debito'] ?>%)</option>
                  <option value="boleto">📄 Boleto (R$ <?= number_format($m['taxa_boleto'],2,',','.') ?>)</option>
                </select>
              </div>
            </div>
            <div class="field"><label>Nome do cliente</label><input type="text" name="customer_name" placeholder="João Silva" required></div>
            <div class="field"><label>E-mail do cliente</label><input type="email" name="customer_email" placeholder="cliente@email.com" required></div>
            <button type="submit" class="btn">&#9654; Simular pagamento</button>
          </form>
          <?php if($result): 
            $cls = $result['status'];
            $icons = ['approved'=>'✅','pending'=>'⏳','refused'=>'❌'];
            $labels = ['approved'=>'Aprovado','pending'=>'Pendente','refused'=>'Recusado'];
          ?>
          <div class="result-box <?= $cls ?>">
            <div class="result-title"><?= $icons[$cls]??'•' ?> <?= $labels[$cls]??$cls ?></div>
            <div class="result-row"><span>ID da transação</span><span class="mono"><?= e(substr($result['txnId'],0,20)) ?>...</span></div>
            <div class="result-row"><span>Valor cobrado</span><span><?= money($result['amount']) ?></span></div>
            <div class="result-row"><span>Taxa</span><span style="color:var(--red)">- <?= money($result['fee']) ?></span></div>
            <div class="result-row"><span>Valor líquido</span><span style="color:var(--green);font-weight:700"><?= money($result['net']) ?></span></div>
            <div class="result-row"><span>Método</span><span><?= $result['method'] ?></span></div>
            <div class="result-row"><span>Cliente</span><span><?= e($result['cname']) ?></span></div>
          </div>
          <?php endif ?>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div class="card-title">Suas taxas configuradas</div></div>
        <div class="card-body">
          <?php
          $taxas = [['PIX','🏦',$m['taxa_pix'].'%','var(--green)'],['Crédito','💳',$m['taxa_credito'].'%','var(--blue)'],['Débito','🏧',$m['taxa_debito'].'%','var(--blue2)'],['Boleto','📄','R$ '.number_format($m['taxa_boleto'],2,',','.'),'var(--yellow)']];
          foreach($taxas as $t): ?>
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border)">
            <span style="font-size:14px"><?=$t[1]?> <?=$t[0]?></span>
            <span style="font-family:'JetBrains Mono',monospace;font-weight:700;font-size:14px;color:<?=$t[3]?>"><?=$t[2]?></span>
          </div>
          <?php endforeach ?>
        </div>
      </div>
    </div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
