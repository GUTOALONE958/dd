<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();
$db = db();
$mid = $m['id'];

// Filters
$status = $_GET['status'] ?? '';
$method = $_GET['method'] ?? '';
$search = trim($_GET['q'] ?? '');
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 20;
$offset = ($page - 1) * $limit;

$where  = ['t.merchant_id = ?'];
$params = [$mid];

if ($status) { $where[] = 't.status = ?'; $params[] = $status; }
if ($method)  { $where[] = 't.method = ?'; $params[] = $method; }
if ($search)  { $where[] = '(t.txn_id LIKE ? OR t.customer_name LIKE ? OR t.customer_email LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }

$whereStr = implode(' AND ', $where);

$total = $db->prepare("SELECT COUNT(*) FROM transactions t WHERE $whereStr");
$total->execute($params); $total = (int)$total->fetchColumn();
$pages = ceil($total / $limit);

$stmt = $db->prepare("SELECT * FROM transactions t WHERE $whereStr ORDER BY t.created_at DESC LIMIT $limit OFFSET $offset");
$stmt->execute($params);
$txns = $stmt->fetchAll();

function badge($s){$map=['approved'=>['Aprovado','#10b981','rgba(16,185,129,.12)'],'pending'=>['Pendente','#f59e0b','rgba(245,158,11,.12)'],'refused'=>['Recusado','#ef4444','rgba(239,68,68,.12)'],'refunded'=>['Estornado','#60a5fa','rgba(96,165,250,.12)'],'processing'=>['Processando','#a78bfa','rgba(167,139,250,.12)'],'cancelled'=>['Cancelado','#9ca3af','rgba(156,163,175,.12)']];$b=$map[$s]??[$s,'#9ca3af','rgba(156,163,175,.12)'];return "<span style='padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;font-family:JetBrains Mono,monospace;background:{$b[2]};color:{$b[1]}'>{$b[0]}</span>";}
function mIcon($m){return match($m){'pix'=>'🏦','credit_card'=>'💳','debit_card'=>'🏧','boleto'=>'📄',default=>'💰'};}
function mLabel($m){return match($m){'pix'=>'PIX','credit_card'=>'Crédito','debit_card'=>'Débito','boleto'=>'Boleto',default=>$m};}
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Transações — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--sidebar:230px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.logo-text{font-size:18px;font-weight:800;color:var(--text)}.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px}
.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}
.sb-label{font-size:10px;letter-spacing:1px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase}
.sb-val{font-size:20px;font-weight:800;letter-spacing:-1px;margin:4px 0;font-family:'JetBrains Mono',monospace}
.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:6px;border-radius:7px;margin-top:8px}
.sidebar-nav{flex:1;padding:14px 10px;overflow-y:auto}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:#f1f5f9;color:var(--text)}.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}
.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--text3)}
.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px}
.user-logout:hover{color:var(--red)}
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;gap:14px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.topbar-sub{font-size:12px;color:var(--text3);margin-left:auto;font-family:'JetBrains Mono',monospace}
.content{padding:22px 26px;flex:1}
.page-head{margin-bottom:20px}.page-head h2{font-size:22px;font-weight:800;letter-spacing:-.3px}
.page-head p{font-size:13px;color:var(--text3);margin-top:3px;font-family:'JetBrains Mono',monospace}
.filters{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
.filters input,.filters select{padding:8px 13px;border:1.5px solid var(--border);border-radius:8px;font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;color:var(--text);background:var(--card);outline:none}
.filters input:focus,.filters select:focus{border-color:var(--blue2)}
.filters input{min-width:200px;flex:1}
.btn-filter{padding:8px 18px;background:var(--blue);color:#fff;border:none;border-radius:8px;font-family:'Plus Jakarta Sans',sans-serif;font-size:13px;font-weight:600;cursor:pointer}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 14px;color:var(--text3);font-size:10px;letter-spacing:1px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}
.tbl td{padding:12px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}.tbl tr:hover td{background:#f8faff}
.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text3)}
.amount{font-family:'JetBrains Mono',monospace;font-weight:700}.amount.pos{color:var(--green)}
.pagination{display:flex;gap:6px;justify-content:center;margin-top:18px;flex-wrap:wrap}
.page-btn{padding:6px 13px;border:1px solid var(--border);border-radius:7px;font-size:13px;color:var(--text2);text-decoration:none;background:var(--card)}
.page-btn.active{background:var(--blue);color:#fff;border-color:var(--blue)}
.page-btn:hover:not(.active){background:var(--bg)}
.total-row{padding:12px 16px;font-size:13px;color:var(--text2);border-top:1px solid var(--border);background:var(--bg)}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--card);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:190}
@media(max-width:640px){
  .hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}
  .sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}
  .main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}
  .filters{flex-direction:column}.filters input{min-width:0}
  .tbl th:nth-child(3),.tbl td:nth-child(3),.tbl th:nth-child(5),.tbl td:nth-child(5){display:none}
}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ÁREA DO LOJISTA</div></div></div></div>
  <div class="sidebar-balance"><div class="sb-label">Saldo disponível</div><div class="sb-val"><?= money($m['balance']) ?></div><a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link active"><span class="ni">⇄</span> Transações</a>
    <a href="withdraw.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Integração</div>
    <a href="api.php" class="nav-link"><span class="ni">⌥</span> API & Chaves</a>
    <a href="checkout_demo.php" class="nav-link"><span class="ni">▣</span> Checkout Demo</a>
    <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    <div class="nav-title">Conta</div>
    <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
    <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div><div><div class="user-name"><?= e(substr($m['name'],0,16)) ?></div><div class="user-role"><?= e($m['merchant_uid']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Transações</div><div class="topbar-sub"><?= date('d/m/Y H:i') ?></div></header>
  <div class="content">
    <div class="page-head"><h2>Suas Transações</h2><p>Total: <?= number_format($total) ?> registro(s)</p></div>
    <form method="GET" class="filters">
      <input type="text" name="q" placeholder="Buscar por ID, cliente..." value="<?= e($search) ?>">
      <select name="status"><option value="">Todos os status</option><option value="approved" <?= $status=='approved'?'selected':'' ?>>Aprovado</option><option value="pending" <?= $status=='pending'?'selected':'' ?>>Pendente</option><option value="refused" <?= $status=='refused'?'selected':'' ?>>Recusado</option><option value="refunded" <?= $status=='refunded'?'selected':'' ?>>Estornado</option></select>
      <select name="method"><option value="">Todos os métodos</option><option value="pix" <?= $method=='pix'?'selected':'' ?>>PIX</option><option value="credit_card" <?= $method=='credit_card'?'selected':'' ?>>Crédito</option><option value="debit_card" <?= $method=='debit_card'?'selected':'' ?>>Débito</option><option value="boleto" <?= $method=='boleto'?'selected':'' ?>>Boleto</option></select>
      <button type="submit" class="btn-filter">Filtrar</button>
    </form>
    <div class="card">
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>ID</th><th>Método</th><th>Cliente</th><th>Valor</th><th>Líquido</th><th>Status</th><th>Data</th></tr></thead>
          <tbody>
            <?php foreach($txns as $t): ?>
            <tr>
              <td><span class="mono"><?= e(substr($t['txn_id'],0,16)) ?>...</span></td>
              <td><?= mIcon($t['method']) ?> <?= mLabel($t['method']) ?></td>
              <td style="font-size:13px"><?= e($t['customer_name']??'—') ?></td>
              <td><span class="amount pos"><?= money($t['amount']) ?></span></td>
              <td><span class="mono" style="color:var(--green)"><?= money($t['net_amount']) ?></span></td>
              <td><?= badge($t['status']) ?></td>
              <td class="mono"><?= date('d/m/y H:i', strtotime($t['created_at'])) ?></td>
            </tr>
            <?php endforeach ?>
            <?php if(!$txns): ?><tr><td colspan="7" style="text-align:center;color:var(--text3);padding:32px">Nenhuma transação encontrada</td></tr><?php endif ?>
          </tbody>
        </table>
      </div>
      <div class="total-row"><?= $total ?> transação(ões) · Página <?= $page ?> de <?= max(1,$pages) ?></div>
    </div>
    <?php if($pages > 1): ?>
    <div class="pagination">
      <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="?page=<?=$i?>&status=<?=urlencode($status)?>&method=<?=urlencode($method)?>&q=<?=urlencode($search)?>" class="page-btn <?= $i==$page?'active':'' ?>"><?=$i?></a>
      <?php endfor ?>
    </div>
    <?php endif ?>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
