<?php
require_once __DIR__.'/../includes/config.php';

$error   = '';
$success = '';
$token   = trim($_GET['token'] ?? $_POST['token'] ?? '');

// Ensure table exists
try {
    db()->exec('
        CREATE TABLE IF NOT EXISTS password_resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(191) NOT NULL,
            token VARCHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            UNIQUE KEY uq_email (email),
            INDEX idx_token (token)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ');
} catch (\Throwable $e) {}

// Validate token
$row = null;
if ($token) {
    $stmt = db()->prepare('SELECT * FROM password_resets WHERE token=? AND expires_at > NOW()');
    $stmt->execute([$token]);
    $row = $stmt->fetch();
}

if (!$row) {
    $error = 'Link inv&aacute;lido ou expirado. Solicite um novo.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $row) {
    csrfCheck();
    $pass  = $_POST['password']  ?? '';
    $pass2 = $_POST['password2'] ?? '';

    if (strlen($pass) < 8) {
        $error = 'A senha deve ter no m&iacute;nimo 8 caracteres.';
    } elseif ($pass !== $pass2) {
        $error = 'As senhas n&atilde;o coincidem.';
    } else {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        db()->prepare('UPDATE merchants SET password=? WHERE email=?')->execute([$hash, $row['email']]);
        db()->prepare('DELETE FROM password_resets WHERE email=?')->execute([$row['email']]);
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nova senha &mdash; <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f8faff;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--green:#10b981;--red:#ef4444}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center}
.bg-pattern{position:fixed;inset:0;background-image:radial-gradient(circle at 20% 20%,rgba(37,99,235,.06) 0%,transparent 50%);pointer-events:none}
.wrap{width:100%;max-width:420px;padding:20px;position:relative;z-index:1}
.card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:42px 38px;box-shadow:0 16px 48px rgba(0,0,0,.08);animation:fadeUp .4s ease both}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
.icon-wrap{width:56px;height:56px;background:rgba(37,99,235,.08);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 24px}
h1{font-size:22px;font-weight:800;text-align:center;margin-bottom:8px}
.subtitle{font-size:14px;color:var(--text2);text-align:center;margin-bottom:28px;line-height:1.5}
.field{margin-bottom:16px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field input{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:9px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.error-box{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;font-size:13px;color:#b91c1c;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.success-box{text-align:center;padding:8px 0}
.success-icon{font-size:48px;margin-bottom:16px}
.success-title{font-size:20px;font-weight:800;color:var(--green);margin-bottom:8px}
.success-desc{font-size:14px;color:var(--text2);line-height:1.5}
.btn{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-appearance:none}
.btn:hover{background:#1d4ed8;transform:translateY(-1px)}
.btn.green{background:var(--green)}
.btn.green:hover{background:#059669}
.back-link{display:block;text-align:center;margin-top:18px;font-size:13px;color:var(--text2)}
.back-link a{color:var(--blue);text-decoration:none;font-weight:600}
@media(max-width:440px){
  .wrap{padding:0}
  .card{border-radius:0;border:none;box-shadow:none;padding:32px 20px;min-height:100vh;min-height:100dvh}
}
</style>
</head>
<body>
<div class="bg-pattern"></div>
<div class="wrap">
  <div class="card">
    <?php if ($success): ?>
      <div class="success-box">
        <div class="success-icon">&#9989;</div>
        <div class="success-title">Senha alterada!</div>
        <p class="success-desc">Sua senha foi redefinida com sucesso. Fa&ccedil;a login com sua nova senha.</p>
      </div>
      <br>
      <a href="<?= BASE_URL ?>/merchant/login.php" class="btn green">Ir para o login &rarr;</a>
    <?php elseif (!$row): ?>
      <div class="icon-wrap">&#10060;</div>
      <h1>Link inv&aacute;lido</h1>
      <p class="subtitle"><?= $error ?></p>
      <a href="<?= BASE_URL ?>/merchant/forgot_password.php" class="btn">Solicitar novo link</a>
      <div class="back-link"><a href="<?= BASE_URL ?>/merchant/login.php">&larr; Voltar ao login</a></div>
    <?php else: ?>
      <div class="icon-wrap">&#128274;</div>
      <h1>Criar nova senha</h1>
      <p class="subtitle">Escolha uma senha forte com pelo menos 8 caracteres.</p>

      <?php if ($error): ?>
      <div class="error-box">&#9888; <?= $error ?></div>
      <?php endif ?>

      <form method="POST">
        <input type="hidden" name="csrf" value="<?= csrf() ?>">
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <div class="field">
          <label>Nova senha</label>
          <input type="password" name="password" placeholder="M&iacute;n. 8 caracteres" required autocomplete="new-password">
        </div>
        <div class="field">
          <label>Confirmar senha</label>
          <input type="password" name="password2" placeholder="Repita a nova senha" required autocomplete="new-password">
        </div>
        <button type="submit" class="btn">Salvar nova senha &rarr;</button>
      </form>
      <div class="back-link"><a href="<?= BASE_URL ?>/merchant/login.php">&larr; Voltar ao login</a></div>
    <?php endif ?>
  </div>
</div>
</body>
</html>
