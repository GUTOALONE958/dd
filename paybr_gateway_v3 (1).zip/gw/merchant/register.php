<?php
require_once __DIR__.'/../includes/config.php';

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $name     = trim($_POST['name']     ?? '');
    $email    = trim($_POST['email']    ?? '');
    $phone    = trim($_POST['phone']    ?? '');
    $document = trim($_POST['document'] ?? '');
    $pass     = $_POST['password']      ?? '';
    $pass2    = $_POST['password2']     ?? '';

    if (!$name || !$email || !$pass) {
        $error = 'Preencha todos os campos obrigat&oacute;rios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'E-mail inv&aacute;lido.';
    } elseif (strlen($pass) < 8) {
        $error = 'A senha deve ter no m&iacute;nimo 8 caracteres.';
    } elseif ($pass !== $pass2) {
        $error = 'As senhas n&atilde;o coincidem.';
    } else {
        // Check duplicate email
        $chk = db()->prepare('SELECT id FROM merchants WHERE email=?');
        $chk->execute([$email]);
        if ($chk->fetch()) {
            $error = 'Este e-mail j&aacute; est&aacute; cadastrado.';
        } else {
            $uid     = uid('M');
            $apiKey  = uid('pk_live_');
            $secret  = uid('sk_live_');
            $hash    = password_hash($pass, PASSWORD_DEFAULT);

            db()->prepare('
                INSERT INTO merchants
                    (name, email, phone, document, password, merchant_uid, api_key, secret_key,
                     status, taxa_pix, taxa_credito, taxa_debito, taxa_boleto, balance, created_at)
                VALUES
                    (?, ?, ?, ?, ?, ?, ?, ?,
                     "active", 1.5, 3.5, 2.5, 3.50, 0, NOW())
            ')->execute([$name, $email, $phone, $document, $hash, $uid, $apiKey, $secret]);

            $merchantId = db()->lastInsertId();
            $_SESSION['merchant_id'] = $merchantId;
            header('Location: '.BASE_URL.'/merchant/index.php'); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Criar Conta &mdash; <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f8faff;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444}
html{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center}
.bg-pattern{position:fixed;inset:0;background-image:radial-gradient(circle at 20% 20%,rgba(37,99,235,.06) 0%,transparent 50%),radial-gradient(circle at 80% 80%,rgba(16,185,129,.06) 0%,transparent 50%);pointer-events:none}
.wrap{width:100%;max-width:520px;padding:20px;position:relative;z-index:1}
.card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:44px 40px;box-shadow:0 20px 60px rgba(0,0,0,.08);animation:fadeUp .4s ease both}
@keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
.brand{display:flex;align-items:center;gap:12px;margin-bottom:32px;justify-content:center}
.brand-icon{width:42px;height:42px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:20px;box-shadow:0 6px 16px rgba(37,99,235,.3);flex-shrink:0}
.brand-name{font-size:21px;font-weight:800;letter-spacing:-.5px}
.brand-name span{color:var(--blue2)}
.brand-badge{font-size:10px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:1px}
h1{font-size:24px;font-weight:800;letter-spacing:-.4px;margin-bottom:6px}
.subtitle{font-size:14px;color:var(--text2);margin-bottom:28px}
.row-2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.field{margin-bottom:16px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field label .req{color:var(--red)}
.field input{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:9px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus{border-color:var(--blue2);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.field input::placeholder{color:var(--text3)}
.error-box{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;font-size:13px;color:#b91c1c;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.btn{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-appearance:none;margin-top:6px}
.btn:hover{background:#1d4ed8;transform:translateY(-1px);box-shadow:0 6px 16px rgba(37,99,235,.3)}
.terms{font-size:12px;color:var(--text3);text-align:center;margin-top:16px}
.terms a{color:var(--blue);text-decoration:none}
.footer{text-align:center;margin-top:24px;font-size:13px;color:var(--text2)}
.footer a{color:var(--blue);text-decoration:none;font-weight:600}
.footer a:hover{text-decoration:underline}
@media(max-width:540px){
  .wrap{padding:0}
  .card{border-radius:0;padding:28px 18px;min-height:100vh;min-height:100dvh;box-shadow:none;border:none}
  .row-2{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="bg-pattern"></div>
<div class="wrap">
  <div class="card">
    <div class="brand">
      <div class="brand-icon">&#9889;</div>
      <div>
        <div class="brand-name">Pay<span>BR</span></div>
        <div class="brand-badge">CADASTRO DE LOJISTA</div>
      </div>
    </div>

    <h1>Criar sua conta</h1>
    <p class="subtitle">Comece a aceitar pagamentos em minutos, sem burocracia.</p>

    <?php if ($error): ?>
    <div class="error-box">&#9888; <?= $error ?></div>
    <?php endif ?>

    <form method="POST">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">

      <div class="field">
        <label>Nome completo / Raz&atilde;o social <span class="req">*</span></label>
        <input type="text" name="name" placeholder="Sua empresa ou nome" value="<?= e($_POST['name']??'') ?>" required autocomplete="name">
      </div>

      <div class="row-2">
        <div class="field">
          <label>E-mail <span class="req">*</span></label>
          <input type="email" name="email" placeholder="seu@email.com" value="<?= e($_POST['email']??'') ?>" required autocomplete="email">
        </div>
        <div class="field">
          <label>Telefone</label>
          <input type="tel" name="phone" placeholder="(11) 9xxxx-xxxx" value="<?= e($_POST['phone']??'') ?>" autocomplete="tel">
        </div>
      </div>

      <div class="field">
        <label>CPF / CNPJ</label>
        <input type="text" name="document" placeholder="000.000.000-00" value="<?= e($_POST['document']??'') ?>">
      </div>

      <div class="row-2">
        <div class="field">
          <label>Senha <span class="req">*</span></label>
          <input type="password" name="password" placeholder="M&iacute;n. 8 caracteres" required autocomplete="new-password">
        </div>
        <div class="field">
          <label>Confirmar senha <span class="req">*</span></label>
          <input type="password" name="password2" placeholder="Repita a senha" required autocomplete="new-password">
        </div>
      </div>

      <button type="submit" class="btn">Criar conta agora &rarr;</button>
    </form>

    <p class="terms">Ao criar uma conta, voc&ecirc; concorda com os <a href="#">Termos de Uso</a> e <a href="#">Pol&iacute;tica de Privacidade</a>.</p>
  </div>

  <div class="footer">
    J&aacute; tem conta? <a href="<?= BASE_URL ?>/merchant/login.php">Fazer login</a>
  </div>
</div>
</body>
</html>
