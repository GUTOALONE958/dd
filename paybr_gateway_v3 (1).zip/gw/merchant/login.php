<?php
require_once __DIR__.'/../includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM merchants WHERE email=? AND status="active"');
    $stmt->execute([$email]);
    $merchant = $stmt->fetch();

    if ($merchant && password_verify($pass, $merchant['password'])) {
        $_SESSION['merchant_id'] = $merchant['id'];
        header('Location: '.BASE_URL.'/merchant/index.php'); exit;
    } else {
        $error = 'E-mail ou senha incorretos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>&#193;rea do Lojista &mdash; <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f8faff;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--dark:#0f172a;--red:#ef4444}
html{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center}
.bg-pattern{position:fixed;inset:0;background-image:radial-gradient(circle at 20% 20%,rgba(37,99,235,.06) 0%,transparent 50%),radial-gradient(circle at 80% 80%,rgba(16,185,129,.06) 0%,transparent 50%);pointer-events:none}

/* Layout desktop: 2 colunas */
.login-wrap{width:100%;max-width:960px;display:grid;grid-template-columns:1fr 1fr;min-height:540px;box-shadow:0 20px 60px rgba(0,0,0,.12);border-radius:20px;overflow:hidden;position:relative;z-index:1}

/* Painel esquerdo */
.left-panel{background:linear-gradient(145deg,#0f172a,#1e3a5f);color:#fff;padding:48px;display:flex;flex-direction:column;justify-content:space-between}
.left-brand{display:flex;align-items:center;gap:12px;margin-bottom:48px}
.lb-icon{width:42px;height:42px;background:rgba(255,255,255,.1);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;border:1px solid rgba(255,255,255,.15);flex-shrink:0}
.lb-name{font-size:20px;font-weight:800}
.lb-name span{color:#60a5fa}
.left-headline{font-size:30px;font-weight:800;line-height:1.2;letter-spacing:-.5px;margin-bottom:20px}
.left-headline span{color:#60a5fa}
.left-desc{font-size:14px;color:rgba(255,255,255,.6);line-height:1.6}
.features{display:flex;flex-direction:column;gap:14px;margin-top:36px}
.feature{display:flex;align-items:center;gap:12px;font-size:13px;color:rgba(255,255,255,.75)}
.feature-dot{width:28px;height:28px;background:rgba(59,130,246,.2);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;border:1px solid rgba(59,130,246,.3)}
.left-footer{font-size:11px;color:rgba(255,255,255,.3);margin-top:auto;padding-top:32px;font-family:'JetBrains Mono',monospace}

/* Formulario direito */
.right-panel{background:var(--card);padding:48px;overflow-y:auto}
.form-header{margin-bottom:36px}
.form-header h1{font-size:26px;font-weight:800;letter-spacing:-.4px;margin-bottom:6px}
.form-header p{font-size:14px;color:var(--text2)}
.field{margin-bottom:18px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field input{width:100%;padding:12px 15px;border:1.5px solid var(--border);border-radius:9px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus{border-color:var(--blue2);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.field input::placeholder{color:var(--text3)}
.error-box{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;font-size:13px;color:#b91c1c;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.btn-login{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:16px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-appearance:none}
.btn-login:hover{background:#1d4ed8;transform:translateY(-1px);box-shadow:0 6px 16px rgba(37,99,235,.3)}
.form-links{display:flex;justify-content:space-between;align-items:center;margin-top:20px;font-size:13px;color:var(--text2)}
.form-links a{color:var(--blue);text-decoration:none;font-weight:500}
.form-links a:hover{text-decoration:underline}
.divider{display:flex;align-items:center;gap:12px;margin:22px 0;color:var(--text3);font-size:12px}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:var(--border)}
.btn-register{display:block;width:100%;padding:12px;background:transparent;color:var(--blue);border:1.5px solid var(--blue);border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;text-align:center;text-decoration:none;-webkit-appearance:none}
.btn-register:hover{background:rgba(37,99,235,.06)}

/* Mobile: painel esquerdo some, formulario ocupa tela toda */
@media(max-width:700px){
  body{align-items:flex-start}
  .login-wrap{grid-template-columns:1fr;max-width:100%;box-shadow:none;border-radius:0;min-height:100vh;min-height:100dvh}
  .left-panel{display:none}
  .right-panel{padding:32px 22px;min-height:100vh;min-height:100dvh}
  .form-header h1{font-size:22px}
}
</style>
</head>
<body>
<div class="bg-pattern"></div>

<div class="login-wrap">
  <div class="left-panel">
    <div>
      <div class="left-brand">
        <div class="lb-icon">&#9889;</div>
        <div class="lb-name">Pay<span>BR</span></div>
      </div>
      <div class="left-headline">Gerencie seus <span>pagamentos</span> com confian&ccedil;a</div>
      <div class="left-desc">Aceite PIX, cart&otilde;es e boleto com as melhores taxas do mercado. Tudo em um &uacute;nico painel.</div>
      <div class="features">
        <div class="feature"><div class="feature-dot">&#9889;</div> PIX instant&acirc;neo com aprova&ccedil;&atilde;o em segundos</div>
        <div class="feature"><div class="feature-dot">&#128179;</div> Cr&eacute;dito e d&eacute;bito com antifraude avan&ccedil;ado</div>
        <div class="feature"><div class="feature-dot">&#128202;</div> Dashboard completo em tempo real</div>
        <div class="feature"><div class="feature-dot">&#128279;</div> API REST para integra&ccedil;&atilde;o com qualquer sistema</div>
      </div>
    </div>
    <div class="left-footer">paybr.com.br &middot; Seguran&ccedil;a SSL &middot; PCI DSS</div>
  </div>

  <div class="right-panel">
    <div class="form-header">
      <h1>Entrar na sua conta</h1>
      <p>Acesse o painel do lojista para gerenciar pagamentos</p>
    </div>

    <?php if ($error): ?>
    <div class="error-box">&#9888; <?= e($error) ?></div>
    <?php endif ?>

    <form method="POST">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <div class="field">
        <label>E-mail</label>
        <input type="email" name="email" placeholder="seu@email.com" value="<?= e($_POST['email']??'') ?>" required autofocus autocomplete="email">
      </div>
      <div class="field">
        <label>Senha</label>
        <input type="password" name="password" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn-login">Acessar minha conta &rarr;</button>
    </form>

    <div class="form-links">
      <a href="<?= BASE_URL ?>/merchant/forgot_password.php">Esqueci minha senha</a>
      <a href="<?= BASE_URL ?>/admin/login.php">Acesso Admin</a>
    </div>

    <div class="divider">novo por aqui?</div>
    <a href="<?= BASE_URL ?>/merchant/register.php" class="btn-register">Criar conta de lojista</a>
  </div>
</div>
</body>
</html>
