<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    // Merchant settings are managed by admin (taxa, etc.)
    $success = 'Configurações salvas.';
}
?>
<!DOCTYPE html><html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Configurações — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--sidebar:230px}html,body{height:100%}body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200}.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}.logo-wrap{display:flex;align-items:center;gap:10px}.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}.logo-text{font-size:18px;font-weight:800;color:var(--text)}.logo-text span{color:var(--blue2)}.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px}.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}.sb-label{font-size:10px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase;letter-spacing:1px}.sb-val{font-size:20px;font-weight:800;font-family:'JetBrains Mono',monospace;margin:4px 0}.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:6px;border-radius:7px;margin-top:8px}.sidebar-nav{flex:1;padding:14px 10px}.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}.nav-link:hover{background:#f1f5f9;color:var(--text)}.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}.user-card{display:flex;align-items:center;gap:10px}.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}.user-name{font-size:13px;font-weight:600}.user-role{font-size:11px;color:var(--text3)}.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px}.user-logout:hover{color:var(--red)}.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;position:sticky;top:0;z-index:100}.topbar-title{font-size:16px;font-weight:700}.content{padding:22px 26px;flex:1}.page-head{margin-bottom:22px}.page-head h2{font-size:22px;font-weight:800}.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:16px;max-width:600px}.card-head{padding:16px 20px;border-bottom:1px solid var(--border)}.card-title{font-size:14px;font-weight:700}.card-body{padding:20px}.info-row{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid var(--border);font-size:14px}.info-row:last-child{border-bottom:none}.info-label{color:var(--text2)}.info-val{font-family:'JetBrains Mono',monospace;font-weight:600}.success-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:11px 14px;font-size:13px;color:#166534;margin-bottom:14px;max-width:600px}
.hamburger{display:none;position:fixed;top:14px;left:14px;z-index:400;background:var(--card);border:1px solid var(--border);border-radius:9px;width:40px;height:40px;align-items:center;justify-content:center;cursor:pointer;font-size:18px}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:190}
@media(max-width:640px){.hamburger{display:flex}.sidebar{transform:translateX(-100%);transition:transform .25s ease}.sidebar.open{transform:translateX(0)}.sidebar-overlay.open{display:block}.main{margin-left:0}.topbar{padding:0 12px 0 58px}.content{padding:14px 12px}.card{max-width:100%}}
</style></head><body>
<div class="hamburger" id="ham" onclick="toggleSidebar()">&#9776;</div>
<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><div class="logo-wrap"><div class="logo-icon">&#9889;</div><div><div class="logo-text">Pay<span>BR</span></div><div class="logo-env">ÁREA DO LOJISTA</div></div></div></div>
  <div class="sidebar-balance"><div class="sb-label">Saldo disponível</div><div class="sb-val"><?= money($m['balance']) ?></div><a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a></div>
  <nav class="sidebar-nav">
    <div class="nav-title">Principal</div>
    <a href="index.php" class="nav-link"><span class="ni">◈</span> Dashboard</a>
    <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
    <a href="withdraw.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    <div class="nav-title">Integração</div>
    <a href="api.php" class="nav-link"><span class="ni">⌥</span> API & Chaves</a>
    <a href="checkout_demo.php" class="nav-link"><span class="ni">▣</span> Checkout Demo</a>
    <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    <div class="nav-title">Conta</div>
    <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
    <a href="settings.php" class="nav-link active"><span class="ni">⚙</span> Configurações</a>
  </nav>
  <div class="sidebar-user"><div class="user-card"><div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div><div><div class="user-name"><?= e(substr($m['name'],0,16)) ?></div><div class="user-role"><?= e($m['merchant_uid']) ?></div></div><a href="logout.php" class="user-logout" title="Sair">⎋</a></div></div>
</aside>
<div class="main">
  <header class="topbar"><div class="topbar-title">Configurações</div></header>
  <div class="content">
    <div class="page-head"><h2>Configurações da Conta</h2></div>
    <?php if($success): ?><div class="success-box">&#9989; <?= e($success) ?></div><?php endif ?>
    <div class="card">
      <div class="card-head"><div class="card-title">Taxas aplicadas</div></div>
      <div class="card-body">
        <div class="info-row"><span class="info-label">&#127974; PIX</span><span class="info-val" style="color:var(--green)"><?= number_format($m['taxa_pix'],2,',','.') ?>%</span></div>
        <div class="info-row"><span class="info-label">&#128179; Crédito</span><span class="info-val" style="color:var(--blue)"><?= number_format($m['taxa_credito'],2,',','.') ?>%</span></div>
        <div class="info-row"><span class="info-label">&#127975; Débito</span><span class="info-val" style="color:var(--blue2)"><?= number_format($m['taxa_debito'],2,',','.') ?>%</span></div>
        <div class="info-row"><span class="info-label">&#128196; Boleto</span><span class="info-val" style="color:var(--yellow)">R$ <?= number_format($m['taxa_boleto'],2,',','.') ?></span></div>
        <p style="font-size:12px;color:var(--text3);margin-top:12px">As taxas são configuradas pelo administrador. Entre em contato para negociação.</p>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div class="card-title">Informações da conta</div></div>
      <div class="card-body">
        <div class="info-row"><span class="info-label">ID do Lojista</span><span class="info-val"><?= e($m['merchant_uid']) ?></span></div>
        <div class="info-row"><span class="info-label">Status</span><span class="info-val" style="color:var(--green)">● Ativo</span></div>
        <div class="info-row"><span class="info-label">Membro desde</span><span class="info-val"><?= isset($m['created_at']) ? date('d/m/Y', strtotime($m['created_at'])) : '—' ?></span></div>
      </div>
    </div>
    <div class="card" style="border-color:#fecaca">
      <div class="card-head" style="background:#fef2f2"><div class="card-title" style="color:var(--red)">Zona de perigo</div></div>
      <div class="card-body">
        <p style="font-size:13px;color:var(--text2);margin-bottom:14px">Para encerrar sua conta ou fazer alterações sensíveis, entre em contato com o suporte.</p>
        <a href="mailto:suporte@paybr.com.br" style="color:var(--red);font-size:13px;font-weight:600;text-decoration:none">&#9993; Contatar suporte →</a>
      </div>
    </div>
  </div>
</div>
<script>function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('overlay').classList.toggle('open');}</script>
</body></html>
