<?php
require_once __DIR__.'/../includes/config.php';

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Informe um e-mail v&aacute;lido.';
    } else {
        $stmt = db()->prepare('SELECT * FROM merchants WHERE email=? AND status="active"');
        $stmt->execute([$email]);
        $merchant = $stmt->fetch();

        if ($merchant) {
            // Generate secure token
            $token   = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Save token (create table if missing — handled in SQL below)
            try {
                db()->prepare('
                    INSERT INTO password_resets (email, token, expires_at, created_at)
                    VALUES (?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE token=VALUES(token), expires_at=VALUES(expires_at), created_at=NOW()
                ')->execute([$email, $token, $expires]);
            } catch (\Throwable $e) {
                // Table may not exist yet — create it
                db()->exec('
                    CREATE TABLE IF NOT EXISTS password_resets (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        email VARCHAR(191) NOT NULL,
                        token VARCHAR(64) NOT NULL,
                        expires_at DATETIME NOT NULL,
                        created_at DATETIME NOT NULL,
                        UNIQUE KEY uq_email (email),
                        INDEX idx_token (token)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                ');
                db()->prepare('
                    INSERT INTO password_resets (email, token, expires_at, created_at)
                    VALUES (?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE token=VALUES(token), expires_at=VALUES(expires_at), created_at=NOW()
                ')->execute([$email, $token, $expires]);
            }

            $link = BASE_URL.'/merchant/reset_password.php?token='.urlencode($token);

            // Send email (PHP mail() — configure SMTP via php.ini / SendGrid / etc.)
            $subject = 'Redefini&ccedil;&atilde;o de senha — '.SITE_NAME;
            $body    = "Ol&aacute;, {$merchant['name']}!\n\n"
                     . "Recebemos um pedido para redefinir a senha da sua conta.\n\n"
                     . "Clique no link abaixo para criar uma nova senha (v&aacute;lido por 1 hora):\n\n"
                     . $link . "\n\n"
                     . "Se voc&ecirc; n&atilde;o solicitou isso, ignore este e-mail.\n\n"
                     . "Equipe " . SITE_NAME;

            $headers = "From: no-reply@paybr.com.br\r\nContent-Type: text/plain; charset=UTF-8";
            @mail($merchant['email'], $subject, $body, $headers);
        }

        // Always show success (security: don't reveal if email exists)
        $success = 'Se o e-mail estiver cadastrado, voc&ecirc; receber&aacute; as instru&ccedil;&otilde;es em instantes.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Esqueci a senha &mdash; <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f8faff;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--blue:#2563eb;--green:#10b981;--red:#ef4444}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;min-height:100dvh;display:flex;align-items:center;justify-content:center}
.bg-pattern{position:fixed;inset:0;background-image:radial-gradient(circle at 20% 20%,rgba(37,99,235,.06) 0%,transparent 50%);pointer-events:none}
.wrap{width:100%;max-width:420px;padding:20px;position:relative;z-index:1}
.card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:42px 38px;box-shadow:0 16px 48px rgba(0,0,0,.08);animation:fadeUp .4s ease both}
@keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
.icon-wrap{width:56px;height:56px;background:rgba(37,99,235,.08);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 24px}
h1{font-size:22px;font-weight:800;text-align:center;margin-bottom:8px}
.subtitle{font-size:14px;color:var(--text2);text-align:center;margin-bottom:28px;line-height:1.5}
.field{margin-bottom:18px}
.field label{display:block;font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:7px}
.field input{width:100%;padding:12px 14px;border:1.5px solid var(--border);border-radius:9px;color:var(--text);font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;outline:none;transition:all .2s;background:#fff;-webkit-appearance:none}
.field input:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.field input::placeholder{color:var(--text3)}
.error-box{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:11px 14px;font-size:13px;color:#b91c1c;margin-bottom:18px;display:flex;align-items:center;gap:8px}
.success-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 16px;font-size:14px;color:#166534;margin-bottom:18px;text-align:center;line-height:1.5}
.btn{width:100%;padding:13px;background:var(--blue);color:#fff;border:none;border-radius:9px;font-family:'Plus Jakarta Sans',sans-serif;font-size:15px;font-weight:700;cursor:pointer;transition:all .2s;-webkit-appearance:none}
.btn:hover{background:#1d4ed8;transform:translateY(-1px)}
.back-link{display:block;text-align:center;margin-top:20px;font-size:13px;color:var(--text2)}
.back-link a{color:var(--blue);text-decoration:none;font-weight:600}
.back-link a:hover{text-decoration:underline}
@media(max-width:440px){
  .wrap{padding:0}
  .card{border-radius:0;border:none;box-shadow:none;padding:32px 20px;min-height:100vh;min-height:100dvh}
}
</style>
</head>
<body>
<div class="bg-pattern"></div>
<div class="wrap">
  <div class="card">
    <div class="icon-wrap">&#128274;</div>
    <h1>Esqueceu a senha?</h1>
    <p class="subtitle">Sem problema! Informe seu e-mail e enviaremos um link para criar uma nova senha.</p>

    <?php if ($error): ?>
    <div class="error-box">&#9888; <?= $error ?></div>
    <?php endif ?>

    <?php if ($success): ?>
    <div class="success-box">&#9989; <?= $success ?></div>
    <div class="back-link"><a href="<?= BASE_URL ?>/merchant/login.php">&larr; Voltar ao login</a></div>
    <?php else: ?>
    <form method="POST">
      <input type="hidden" name="csrf" value="<?= csrf() ?>">
      <div class="field">
        <label>E-mail</label>
        <input type="email" name="email" placeholder="seu@email.com" value="<?= e($_POST['email']??'') ?>" required autofocus autocomplete="email">
      </div>
      <button type="submit" class="btn">Enviar link de redefini&ccedil;&atilde;o &rarr;</button>
    </form>
    <div class="back-link"><a href="<?= BASE_URL ?>/merchant/login.php">&larr; Voltar ao login</a></div>
    <?php endif ?>
  </div>
</div>
</body>
</html>
