<?php
require_once __DIR__.'/../includes/config.php';
$m = authMerchant();
$db = db();
$mid = $m['id'];

// Stats
$stats = $db->prepare("
    SELECT
        COUNT(*) total,
        SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) approved,
        SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) volume,
        SUM(CASE WHEN status='approved' THEN fee ELSE 0 END) fees,
        SUM(CASE WHEN DATE(created_at)=CURDATE() AND status='approved' THEN amount ELSE 0 END) today_vol,
        SUM(CASE WHEN DATE(created_at)=CURDATE() THEN 1 ELSE 0 END) today_txn,
        SUM(CASE WHEN MONTH(created_at)=MONTH(NOW()) AND status='approved' THEN amount ELSE 0 END) month_vol
    FROM transactions WHERE merchant_id=?
");
$stats->execute([$mid]); $stats=$stats->fetch();

$approval_rate = $stats['total']>0 ? round($stats['approved']/$stats['total']*100,1) : 0;

// Recent
$recent = $db->prepare("SELECT * FROM transactions WHERE merchant_id=? ORDER BY created_at DESC LIMIT 8");
$recent->execute([$mid]); $recent=$recent->fetchAll();

// Chart - 7 dias
$chart = $db->prepare("
    SELECT DATE(created_at) d, SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) v, COUNT(*) c
    FROM transactions WHERE merchant_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)
    GROUP BY DATE(created_at) ORDER BY d
");
$chart->execute([$mid]); $chart=$chart->fetchAll();

// Methods
$methods = $db->prepare("SELECT method, COUNT(*) c, SUM(CASE WHEN status='approved' THEN amount ELSE 0 END) vol FROM transactions WHERE merchant_id=? GROUP BY method");
$methods->execute([$mid]); $methods=$methods->fetchAll();

function badge($s){
    $map=['approved'=>['Aprovado','#10b981','rgba(16,185,129,.12)'],'pending'=>['Pendente','#f59e0b','rgba(245,158,11,.12)'],'refused'=>['Recusado','#ef4444','rgba(239,68,68,.12)'],'refunded'=>['Estornado','#60a5fa','rgba(96,165,250,.12)']];
    $b=$map[$s]??[$s,'#9ca3af','rgba(156,163,175,.12)'];
    return "<span style='padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;font-family:JetBrains Mono,monospace;background:{$b[2]};color:{$b[1]}'>{$b[0]}</span>";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard — <?= SITE_NAME ?></title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#f1f5f9;--card:#fff;--text:#0f172a;--text2:#475569;--text3:#94a3b8;--border:#e2e8f0;--border2:#cbd5e1;--blue:#2563eb;--blue2:#3b82f6;--green:#10b981;--red:#ef4444;--yellow:#f59e0b;--purple:#8b5cf6;--sidebar:230px}
html,body{height:100%}
body{font-family:'Plus Jakarta Sans',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}

/* ── SIDEBAR (LIGHT) ── */
.sidebar{width:var(--sidebar);min-height:100vh;background:var(--card);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;z-index:200;box-shadow:1px 0 10px rgba(0,0,0,.04)}
.sidebar-logo{padding:22px 20px 18px;border-bottom:1px solid var(--border)}
.logo-wrap{display:flex;align-items:center;gap:10px}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;box-shadow:0 4px 12px rgba(37,99,235,.25)}
.logo-text{font-size:18px;font-weight:800;letter-spacing:-.3px;color:var(--text)}
.logo-text span{color:var(--blue2)}
.logo-env{font-size:9px;color:var(--text3);font-family:'JetBrains Mono',monospace;letter-spacing:2px;margin-top:1px}

.sidebar-nav{flex:1;padding:14px 10px;overflow-y:auto}
.nav-section{margin-bottom:6px}
.nav-title{font-size:9px;letter-spacing:2px;color:var(--text3);padding:8px 10px 4px;text-transform:uppercase;font-family:'JetBrains Mono',monospace}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;color:var(--text2);font-size:13.5px;font-weight:500;text-decoration:none;transition:all .15s;margin-bottom:1px}
.nav-link:hover{background:#f1f5f9;color:var(--text)}
.nav-link.active{background:rgba(37,99,235,.08);color:var(--blue);font-weight:600}
.ni{width:20px;text-align:center;font-size:15px;flex-shrink:0}

.sidebar-balance{margin:10px;padding:14px 16px;background:linear-gradient(135deg,#2563eb,#1d4ed8);border-radius:12px;color:#fff}
.sb-label{font-size:10px;letter-spacing:1px;opacity:.8;font-family:'JetBrains Mono',monospace;text-transform:uppercase}
.sb-val{font-size:22px;font-weight:800;letter-spacing:-1px;margin:4px 0;font-family:'JetBrains Mono',monospace}
.sb-btn{display:block;text-align:center;background:rgba(255,255,255,.2);color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:7px;border-radius:7px;margin-top:10px;transition:background .15s}
.sb-btn:hover{background:rgba(255,255,255,.3)}

.sidebar-user{padding:14px 16px;border-top:1px solid var(--border)}
.user-card{display:flex;align-items:center;gap:10px}
.user-avatar{width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
.user-name{font-size:13px;font-weight:600;color:var(--text)}
.user-role{font-size:11px;color:var(--text3)}
.user-logout{margin-left:auto;color:var(--text3);text-decoration:none;font-size:15px;transition:color .15s}
.user-logout:hover{color:var(--red)}

/* ── MAIN ── */
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column}
.topbar{height:56px;background:var(--card);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 26px;gap:14px;position:sticky;top:0;z-index:100}
.topbar-title{font-size:16px;font-weight:700}
.topbar-sub{font-size:12px;color:var(--text3);margin-left:auto;font-family:'JetBrains Mono',monospace}
.topbar-btn{padding:7px 16px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;border:1px solid var(--border);background:var(--bg);color:var(--text2);font-family:'Plus Jakarta Sans',sans-serif;text-decoration:none;transition:all .15s}
.topbar-btn:hover{border-color:var(--border2);color:var(--text)}
.topbar-btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}
.topbar-btn.primary:hover{background:#1d4ed8}

.content{padding:22px 26px;flex:1}
.page-head{margin-bottom:22px}
.page-head h2{font-size:22px;font-weight:800;letter-spacing:-.3px}
.page-head p{font-size:13px;color:var(--text3);margin-top:3px;font-family:'JetBrains Mono',monospace}

/* STATS */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:18px 20px;transition:box-shadow .2s,transform .2s}
.stat:hover{box-shadow:0 4px 16px rgba(0,0,0,.08);transform:translateY(-1px)}
.stat-icon{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:17px;margin-bottom:12px}
.stat-label{font-size:11px;color:var(--text3);letter-spacing:.6px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;margin-bottom:6px}
.stat-val{font-size:22px;font-weight:800;letter-spacing:-.5px;color:var(--text)}
.stat-footer{font-size:12px;color:var(--text3);margin-top:6px}
.stat-footer .up{color:var(--green);font-weight:600}

/* GRID */
.grid-2{display:grid;grid-template-columns:1fr 320px;gap:14px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.card-head{padding:16px 20px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:14px;font-weight:700}
.card-sub{font-size:11px;color:var(--text3);font-family:'JetBrains Mono',monospace;margin-top:2px}
.card-body{padding:16px 20px}
.card-link{font-size:12px;color:var(--blue);text-decoration:none;font-weight:600}
.card-link:hover{text-decoration:underline}

/* TABLE */
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 14px;color:var(--text3);font-size:10px;letter-spacing:1px;text-transform:uppercase;font-family:'JetBrains Mono',monospace;border-bottom:1px solid var(--border);font-weight:500}
.tbl td{padding:12px 14px;border-bottom:1px solid var(--border);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:#f8faff}
.mono{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--text3)}
.amount{font-family:'JetBrains Mono',monospace;font-weight:700}
.amount.pos{color:var(--green)}

/* METHOD */
.method-row{display:flex;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid var(--border)}
.method-row:last-child{border-bottom:none}
.method-ico{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0}
.method-name{font-size:13px;font-weight:600}
.method-cnt{font-size:11px;color:var(--text3);font-family:'JetBrains Mono',monospace;margin-top:1px}
.method-bar-wrap{flex:1;max-width:80px;height:4px;background:var(--bg);border-radius:2px;overflow:hidden}
.method-bar{height:100%;border-radius:2px}
.method-pct{font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;min-width:34px;text-align:right}

/* API KEY */
.key-box{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px 14px;font-family:'JetBrains Mono',monospace;font-size:12px;word-break:break-all;position:relative;margin-bottom:10px}
.key-copy{position:absolute;top:8px;right:8px;padding:4px 10px;background:var(--blue);color:#fff;border:none;border-radius:5px;font-size:11px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif;font-weight:600;transition:background .15s}
.key-copy:hover{background:#1d4ed8}

@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.stat{animation:fadeUp .35s ease both}
.stat:nth-child(1){animation-delay:.04s}
.stat:nth-child(2){animation-delay:.08s}
.stat:nth-child(3){animation-delay:.12s}
.stat:nth-child(4){animation-delay:.16s}

::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:var(--bg)}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
</style>
</head>
<body>

<!-- ══ SIDEBAR ══ -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-wrap">
      <div class="logo-icon">⚡</div>
      <div>
        <div class="logo-text">Pay<span>BR</span></div>
        <div class="logo-env">ÁREA DO LOJISTA</div>
      </div>
    </div>
  </div>

  <!-- Saldo -->
  <div class="sidebar-balance">
    <div class="sb-label">Saldo disponível</div>
    <div class="sb-val"><?= money($m['balance']) ?></div>
    <a href="withdraw.php" class="sb-btn">↑ Solicitar saque</a>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-title">Principal</div>
      <a href="index.php" class="nav-link active"><span class="ni">◈</span> Dashboard</a>
      <a href="transactions.php" class="nav-link"><span class="ni">⇄</span> Transações</a>
      <a href="withdraw.php" class="nav-link"><span class="ni">↑</span> Saques</a>
    </div>
    <div class="nav-section">
      <div class="nav-title">Integração</div>
      <a href="api.php" class="nav-link"><span class="ni">⌥</span> API & Chaves</a>
      <a href="checkout_demo.php" class="nav-link"><span class="ni">▣</span> Checkout Demo</a>
      <a href="webhook.php" class="nav-link"><span class="ni">🔗</span> Webhook</a>
    </div>
    <div class="nav-section">
      <div class="nav-title">Conta</div>
      <a href="profile.php" class="nav-link"><span class="ni">👤</span> Perfil</a>
      <a href="settings.php" class="nav-link"><span class="ni">⚙</span> Configurações</a>
    </div>
  </nav>

  <div class="sidebar-user">
    <div class="user-card">
      <div class="user-avatar"><?= strtoupper(substr($m['name'],0,1)) ?></div>
      <div>
        <div class="user-name"><?= e(substr($m['name'],0,16)) ?></div>
        <div class="user-role"><?= e($m['merchant_uid']) ?></div>
      </div>
      <a href="logout.php" class="user-logout" title="Sair">⎋</a>
    </div>
  </div>
</aside>

<!-- ══ MAIN ══ -->
<div class="main">
  <header class="topbar">
    <div class="topbar-title">Dashboard</div>
    <div class="topbar-sub">Olá, <?= e(explode(' ', $m['name'])[0]) ?> · <?= date('d/m/Y H:i') ?></div>
    <a href="checkout_demo.php" class="topbar-btn primary">+ Novo Pagamento</a>
  </header>

  <div class="content">
    <div class="page-head">
      <h2>Visão Geral</h2>
      <p>Resumo da sua conta · <?= date('F Y') ?></p>
    </div>

    <!-- STATS -->
    <div class="stats-row">
      <div class="stat">
        <div class="stat-icon" style="background:rgba(16,185,129,.1)">💰</div>
        <div class="stat-label">Volume Total</div>
        <div class="stat-val"><?= money($stats['volume']??0) ?></div>
        <div class="stat-footer">Mês: <span class="up"><?= money($stats['month_vol']??0) ?></span></div>
      </div>
      <div class="stat">
        <div class="stat-icon" style="background:rgba(37,99,235,.1)">📊</div>
        <div class="stat-label">Transações</div>
        <div class="stat-val"><?= number_format($stats['total']??0) ?></div>
        <div class="stat-footer">Hoje: <span class="up"><?= $stats['today_txn']??0 ?></span></div>
      </div>
      <div class="stat">
        <div class="stat-icon" style="background:rgba(245,158,11,.1)">✅</div>
        <div class="stat-label">Taxa de Aprovação</div>
        <div class="stat-val"><?= $approval_rate ?>%</div>
        <div class="stat-footer">Geral da conta</div>
      </div>
      <div class="stat">
        <div class="stat-icon" style="background:rgba(37,99,235,.08)">⚖️</div>
        <div class="stat-label">Saldo Disponível</div>
        <div class="stat-val" style="color:var(--blue)"><?= money($m['balance']) ?></div>
        <div class="stat-footer"><a href="withdraw.php" style="color:var(--blue);text-decoration:none;font-weight:600">Sacar agora →</a></div>
      </div>
    </div>

    <!-- CHART + METHODS -->
    <div class="grid-2">
      <div class="card">
        <div class="card-head">
          <div>
            <div class="card-title">Volume nos Últimos 7 Dias</div>
            <div class="card-sub">Apenas transações aprovadas</div>
          </div>
        </div>
        <div class="card-body">
          <div style="height:150px;position:relative"><canvas id="chartVol"></canvas></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div class="card-title">Por Método</div></div>
        <div class="card-body">
          <?php
          $total_m=array_sum(array_column($methods,'c'))?:1;
          $mcolors=['pix'=>'#10b981','credit_card'=>'#2563eb','debit_card'=>'#60a5fa','boleto'=>'#f59e0b'];
          $mbg=['pix'=>'rgba(16,185,129,.1)','credit_card'=>'rgba(37,99,235,.1)','debit_card'=>'rgba(96,165,250,.1)','boleto'=>'rgba(245,158,11,.1)'];
          $mlabel=['pix'=>'PIX','credit_card'=>'Crédito','debit_card'=>'Débito','boleto'=>'Boleto'];
          $micon=['pix'=>'🏦','credit_card'=>'💳','debit_card'=>'🏧','boleto'=>'📄'];
          foreach($methods as $row):
            $pct=round($row['c']/$total_m*100);
            $c=$mcolors[$row['method']]??'#94a3b8';
            $bg=$mbg[$row['method']]??'rgba(148,163,184,.1)';
          ?>
          <div class="method-row">
            <div class="method-ico" style="background:<?=$bg?>"><?=$micon[$row['method']]??'💰'?></div>
            <div style="flex:1">
              <div class="method-name"><?=$mlabel[$row['method']]??$row['method']?></div>
              <div class="method-cnt"><?=$row['c']?> · <?=money($row['vol'])?></div>
            </div>
            <div class="method-bar-wrap"><div class="method-bar" style="width:<?=$pct?>%;background:<?=$c?>"></div></div>
            <div class="method-pct" style="color:<?=$c?>"><?=$pct?>%</div>
          </div>
          <?php endforeach ?>
          <?php if(!$methods): ?><div style="text-align:center;color:var(--text3);padding:20px;font-size:13px">Sem dados</div><?php endif ?>
        </div>
      </div>
    </div>

    <!-- RECENT + API KEY -->
    <div style="display:grid;grid-template-columns:1fr 300px;gap:14px">
      <div class="card">
        <div class="card-head">
          <div>
            <div class="card-title">Últimas Transações</div>
            <div class="card-sub">Suas cobranças recentes</div>
          </div>
          <a href="transactions.php" class="card-link">Ver todas →</a>
        </div>
        <div style="overflow-x:auto">
          <table class="tbl">
            <thead><tr><th>ID</th><th>Método</th><th>Valor</th><th>Líquido</th><th>Status</th><th>Data</th></tr></thead>
            <tbody>
              <?php foreach($recent as $t): ?>
              <tr>
                <td><span class="mono"><?=e(substr($t['txn_id'],0,16))?></span></td>
                <td style="font-size:13px"><?=$micon[$t['method']]??'💰'?> <?=$mlabel[$t['method']]??$t['method']?></td>
                <td><span class="amount pos"><?=money($t['amount'])?></span></td>
                <td><span class="mono" style="color:var(--green)"><?=money($t['net_amount'])?></span></td>
                <td><?=badge($t['status'])?></td>
                <td class="mono"><?=date('d/m/y H:i',strtotime($t['created_at']))?></td>
              </tr>
              <?php endforeach ?>
              <?php if(!$recent): ?><tr><td colspan="6" style="text-align:center;color:var(--text3);padding:28px">Nenhuma transação</td></tr><?php endif ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- API KEY CARD -->
      <div class="card">
        <div class="card-head"><div class="card-title">Suas Chaves de API</div></div>
        <div class="card-body">
          <div style="font-size:11px;color:var(--text3);margin-bottom:6px;font-family:'JetBrains Mono',monospace;letter-spacing:.8px">CHAVE PÚBLICA</div>
          <div class="key-box" style="color:var(--blue)">
            <?=e(substr($m['api_key'],0,40))?>...
            <button class="key-copy" onclick="copyText('<?=e($m['api_key'])?>',this)">Copiar</button>
          </div>
          <div style="font-size:11px;color:var(--text3);margin-bottom:6px;font-family:'JetBrains Mono',monospace;letter-spacing:.8px">CHAVE SECRETA</div>
          <div class="key-box" id="sk-box" style="color:var(--red)">
            sk_live_••••••••••••••••••••••••••••••
            <button class="key-copy" id="sk-btn" onclick="revealSk()" style="background:var(--text3)">Revelar</button>
          </div>
          <div style="background:#fef9ec;border:1px solid #fde68a;border-radius:8px;padding:10px 12px;font-size:12px;color:#92400e;margin-top:12px">
            ⚠ Nunca exponha a chave secreta no frontend.
          </div>
          <a href="api.php" class="card-link" style="display:block;margin-top:14px;font-size:13px">Ver documentação da API →</a>
        </div>
      </div>
    </div>

  </div>
</div>

<script>
// Chart
const d = <?=json_encode($chart)?>;
const labels = d.map(r=>{const dt=new Date(r.d+'T00:00:00');return dt.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})});
const values = d.map(r=>parseFloat(r.v||0));
new Chart(document.getElementById('chartVol'),{
  type:'line',
  data:{labels,datasets:[{data:values,borderColor:'#2563eb',backgroundColor:'rgba(37,99,235,.08)',borderWidth:2,fill:true,tension:.35,pointBackgroundColor:'#2563eb',pointRadius:3}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{backgroundColor:'#fff',borderColor:'#e2e8f0',borderWidth:1,titleColor:'#0f172a',bodyColor:'#475569',callbacks:{label:ctx=>' R$ '+ctx.raw.toFixed(2).replace('.',',')}}},scales:{x:{grid:{color:'rgba(0,0,0,.04)'},ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:10}}},y:{grid:{color:'rgba(0,0,0,.04)'},ticks:{color:'#94a3b8',font:{family:'JetBrains Mono',size:10},callback:v=>'R$'+v.toFixed(0)}}}}
});

function copyText(txt,btn){navigator.clipboard.writeText(txt).then(()=>{btn.textContent='✓ Copiado';btn.style.background='#10b981';setTimeout(()=>{btn.textContent='Copiar';btn.style.background=''},2000)})}

const sk = '<?=e($m['secret_key'])?>';
let revealed = false;
function revealSk(){
  if(!revealed){
    document.getElementById('sk-box').childNodes[0].textContent = sk.substr(0,40)+'...';
    document.getElementById('sk-box').style.color = '#ef4444';
    document.getElementById('sk-btn').textContent = 'Copiar';
    document.getElementById('sk-btn').style.background = '#2563eb';
    revealed = true;
  } else {
    copyText(sk, document.getElementById('sk-btn'));
  }
}
</script>
</body>
</html>
