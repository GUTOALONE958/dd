-- ══════════════════════════════════════════
--  PayBR Gateway — Banco de Dados
-- ══════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS paybr_gateway
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE paybr_gateway;

-- ── Admins ─────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(120) NOT NULL,
    email      VARCHAR(180) UNIQUE NOT NULL,
    password   VARCHAR(255) NOT NULL,
    role       ENUM('superadmin','admin','support') DEFAULT 'admin',
    status     ENUM('active','inactive') DEFAULT 'active',
    avatar     VARCHAR(255),
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ── Merchants (lojistas) ───────────────────
CREATE TABLE IF NOT EXISTS merchants (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    merchant_uid  VARCHAR(20) UNIQUE NOT NULL,
    name          VARCHAR(200) NOT NULL,
    email         VARCHAR(180) UNIQUE NOT NULL,
    password      VARCHAR(255) NOT NULL,
    document      VARCHAR(25),
    phone         VARCHAR(25),
    website       VARCHAR(255),
    logo          VARCHAR(255),
    api_key       VARCHAR(80) UNIQUE NOT NULL,
    secret_key    VARCHAR(80) NOT NULL,
    webhook_url   VARCHAR(500),
    status        ENUM('active','inactive','suspended','pending') DEFAULT 'pending',
    balance       DECIMAL(15,2) DEFAULT 0.00,
    total_in      DECIMAL(15,2) DEFAULT 0.00,
    taxa_pix      DECIMAL(5,2)  DEFAULT 0.99,
    taxa_credito  DECIMAL(5,2)  DEFAULT 2.99,
    taxa_debito   DECIMAL(5,2)  DEFAULT 1.49,
    taxa_boleto   DECIMAL(8,2)  DEFAULT 2.50,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── Transactions ───────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    txn_id          VARCHAR(24) UNIQUE NOT NULL,
    merchant_id     INT NOT NULL,
    order_id        VARCHAR(120),
    amount          DECIMAL(15,2) NOT NULL,
    fee             DECIMAL(15,2) DEFAULT 0.00,
    net_amount      DECIMAL(15,2) NOT NULL,
    method          ENUM('pix','credit_card','debit_card','boleto') NOT NULL,
    status          ENUM('pending','processing','approved','refused','cancelled','refunded','chargeback') DEFAULT 'pending',
    customer_name   VARCHAR(200),
    customer_email  VARCHAR(200),
    customer_doc    VARCHAR(25),
    customer_phone  VARCHAR(25),
    customer_ip     VARCHAR(45),
    card_last4      VARCHAR(4),
    card_brand      VARCHAR(20),
    installments    TINYINT DEFAULT 1,
    pix_code        TEXT,
    pix_expires     DATETIME,
    boleto_code     VARCHAR(600),
    boleto_url      VARCHAR(500),
    boleto_expires  DATETIME,
    notes           TEXT,
    metadata        JSON,
    approved_at     DATETIME,
    refunded_at     DATETIME,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (merchant_id) REFERENCES merchants(id),
    INDEX idx_merchant (merchant_id),
    INDEX idx_status   (status),
    INDEX idx_created  (created_at)
);

-- ── Withdrawals ────────────────────────────
CREATE TABLE IF NOT EXISTS withdrawals (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    wd_id       VARCHAR(24) UNIQUE NOT NULL,
    merchant_id INT NOT NULL,
    amount      DECIMAL(15,2) NOT NULL,
    fee         DECIMAL(8,2)  DEFAULT 0.00,
    net_amount  DECIMAL(15,2) NOT NULL,
    method      ENUM('pix','ted') DEFAULT 'pix',
    pix_key     VARCHAR(255),
    bank_data   JSON,
    status      ENUM('pending','processing','completed','failed') DEFAULT 'pending',
    admin_note  TEXT,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (merchant_id) REFERENCES merchants(id)
);

-- ── Webhook logs ───────────────────────────
CREATE TABLE IF NOT EXISTS webhook_logs (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    merchant_id INT NOT NULL,
    txn_id     VARCHAR(24),
    event      VARCHAR(80) NOT NULL,
    payload    JSON,
    response   TEXT,
    http_code  SMALLINT,
    attempts   TINYINT DEFAULT 0,
    status     ENUM('pending','sent','failed') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ── Sessions / logs ────────────────────────
CREATE TABLE IF NOT EXISTS login_logs (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_type  ENUM('admin','merchant') NOT NULL,
    user_id    INT NOT NULL,
    ip         VARCHAR(45),
    user_agent VARCHAR(400),
    success    TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ══════════════════════════════════════════
--  Dados iniciais
-- ══════════════════════════════════════════

-- Admin padrão  →  email: admin@paybr.com  /  senha: Admin@123
INSERT IGNORE INTO admins (name, email, password, role) VALUES (
    'Administrador',
    'admin@paybr.com',
    '$2y$12$LcMNBMEwcIZRSVP9k4yjsOO3h0HHCRI5YHQYCpn/gOSXxQDuJ6XWy',
    'superadmin'
);

-- Merchant demo  →  email: loja@demo.com  /  senha: Demo@123
INSERT IGNORE INTO merchants
    (merchant_uid, name, email, password, document, api_key, secret_key, status)
VALUES (
    'MERCH0000001',
    'Loja Demonstração',
    'loja@demo.com',
    '$2y$12$LcMNBMEwcIZRSVP9k4yjsOO3h0HHCRI5YHQYCpn/gOSXxQDuJ6XWy',
    '12.345.678/0001-90',
    CONCAT('pk_live_', SHA2(CONCAT('api_',UUID()),256)),
    CONCAT('sk_live_', SHA2(CONCAT('sec_',UUID()),256)),
    'active'
);
